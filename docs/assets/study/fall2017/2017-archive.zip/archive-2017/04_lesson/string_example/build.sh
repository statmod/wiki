g++-7 -Wall -O2 --std=c++11  -o string_example string_example.cpp
