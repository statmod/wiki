g++-7 -Wall -O2 -fno-elide-constructors --std=c++11 -o move_semantics move_semantics.cpp
