g++-7 -Wall -O0 --std=c++11 -o move_semantics move_semantics.cpp
