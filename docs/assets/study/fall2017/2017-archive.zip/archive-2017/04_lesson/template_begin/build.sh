g++-7 -Wall -O2 --std=c++11 -o array array.cpp
g++-7 -Wall -O2 --std=c++11 -o iterator iterator.cpp
