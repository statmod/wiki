// templ_fun.cpp : Defines the entry point for the console application.

#include <iostream>
#include <cstring>
using std::cout;
using std::cin;
using std::endl;

template <typename T> 
T min (T x, T y) {
	cout<<"T min"<<endl;
	return x<y? x:y;
}

int min(int i, int j)
{
	cout<<"my min"<<endl;
	return ::min<int>(i,j);
	//return std::min<int>(i,j);
}

template<> const char* min(const char * str1, const char * str2)
{
	cout << "char* min" << endl;
	return strcmp(str1,str2)<0? str1:str2;
}

template <typename T1, typename T2> 
void print (T1 x, T2 y) {
	cout<<x<<' '<<y<<endl;
}

template<typename T1, typename T2> 
void print(T1* x, T2* y) {
	cout<<*x<<endl<<*y<<endl;
}

template<typename T, typename U> T implicit_cast (U u) {return u;}

void g(int i) {
	//implicit_cast(i); //cannot deduce template
	implicit_cast<double>(i);
	implicit_cast<char, double>(i);
	//implicit_cast<char*,int>(i);// no conversion from char* to int
}

int main() {
	double z=::min (2.,3.);
	int k;
	k=std::min(2,3);
	k=min (3.,4); //not ambiguous because of explicit form of min
	cout<<z<<' '<<k<<endl;

	const char * str1="abcd", *str2="abcg";
	cout<<::min(str1,str2)<<endl;// std::min работает неправильно, так как сравнивает указатели
	print (k,z);
	print (str1,str2);
	return 0;
}
