#include <iostream>  
  
using namespace std; 

constexpr int my_strcmp( const char* str1, const char* str2 ) {
    int i = 0;
    for( ; str1[i] && str2[i] && str1[i] == str2[i]; ++i )
        { }
    if( str1[i] == str2[i] ) return 0;
    if( str1[i] < str2[i] ) return -1;
    return 1;
}

constexpr const char* mama = "mama";
constexpr const char* mama2 = "mama";
constexpr const char* mamb = "mamb";
constexpr const char* mam0 = "mam0";

int main()  
{   
    //Run time:   
    cout << my_strcmp(mama, mama2) << endl;   
    cout << my_strcmp(mama, mamb) << endl;   
    cout << my_strcmp(mama, mam0) << endl;   
}