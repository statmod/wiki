#include <iostream>  
  
using namespace std;  
  
// Pass by value   
constexpr float pow(float x, int n)  
{  
    return n == 0 ? 1 :  
        n % 2 == 0 ? pow(x * x, n / 2) :  
        pow(x * x, (n - 1) / 2) * x;  
};  
  
// Pass by reference  
constexpr float pow2(const float& x, const int& n)  
{  
    return n == 0 ? 1 :  
        n % 2 == 0 ? pow2(x * x, n / 2) :  
        pow2(x * x, (n - 1) / 2) * x;  
};  
  
// Compile time computation of array length  
template<typename T, int N>  
constexpr int length(const T(&ary)[N])   
{   
    return N;   
}   
  
// Recursive constexpr function  
constexpr int fac(int n)  
{   
    return n == 1 ? 1 : n*fac(n - 1);   
}  
  
// User-defined type  
class Foo  
{  
public:  
    constexpr explicit Foo(int i) : _i(i) {}  
    constexpr int GetValue()  
    {  
        return _i;  
    }  
private:  
    int _i;  
};  
  
int main()  
{  
    //foo is const (only in C++11): 
    constexpr Foo foo(5);   
    // foo = Foo(6); //Error!  
  
    //Compile time:  
    constexpr float x = pow(5, 3);   
    constexpr float y { pow(2, 5) };  
    constexpr int val = foo.GetValue();   
    constexpr int f5 = fac(5);  
    const int nums[] { 1, 2, 3, 4 };  
    const int nums2[length(nums) * 2] { 1, 2, 3, 4, 5, 6, 7, 8 };  
  
    //Run time:   
    cout << x << endl;   
    cout << y << endl;   
    cout << f5 << endl;   
    cout << "The constexpr value of foo is " << val << endl;   
    cout << "The value of foo is " << foo.GetValue() << endl;   
    cout << "length(nums) = " << length(nums) << endl;   
    cout << "length(nums2) = " << length(nums2) << endl;   
  
}  
