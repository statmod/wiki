g++ -Wall -O2 --std=c++11 -o constexpr constexpr.cpp
g++ -Wall -O2 --std=c++14 -o constexpr-14 constexpr-14.cpp
