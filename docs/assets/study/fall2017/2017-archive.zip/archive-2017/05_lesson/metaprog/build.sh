g++ -Wall -O2 --std=c++11 -o metaprog metaprog.cpp
