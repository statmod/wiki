#include<iostream>

using namespace std;

const char* const answer[] =  {"", "fizz", "buzz", "fizzbuzz"};

template <unsigned long T, unsigned long U>
struct FizzBuzz {
	enum {value = 0};
};

template <unsigned long U>
struct FizzBuzz<0, U> {
	enum {value = 1};
};

template <unsigned long T>
struct FizzBuzz<T, 0> {
	enum {value = 2};
};

template <>
struct FizzBuzz<0, 0> {
	enum {value = 3};
};


template <unsigned long N>
struct FizzBuzzWrapper{
	enum {value = FizzBuzz<N % 3, N % 5>::value};
};



int main() {
	cout << answer[FizzBuzzWrapper<30>::value] << endl;
	return 0;
}