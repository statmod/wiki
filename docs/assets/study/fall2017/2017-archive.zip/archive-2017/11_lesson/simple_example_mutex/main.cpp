// simple_example_mutex.cpp
#include <string>
#include <iostream>
#include <thread>
#include <vector>
#include <mutex>
#include <memory>

using namespace std;

// The function we want to execute on the new thread.

void task2(int i, mutex* mtx)
{
    mtx -> lock();
    cout << "task2 says: " << i << "~" 
    << this_thread::get_id() << "\n";
    mtx -> unlock();
}

void task3(int i, mutex& mtx)
{
    lock_guard<mutex> lockGuard(mtx);
    cout << "task3 says: " << i << "~" 
    << this_thread::get_id() << "\n";
}

void task4(int i, mutex& mtx)
{
    unique_lock<mutex> lock(mtx);
    //we can lock & unlock this lock
    //also start unlocked
    cout << "task4 says: " << i << "~" 
    << this_thread::get_id() << "\n";
}

int main()
{
    vector<thread> ts;
    vector<thread> ts3;
    vector<thread> ts4;
 
    mutex my_mutex;
    for (int i = 0; i < 10; i++) {
    	ts.push_back(
            thread(task2, i, &my_mutex));
    } 

    for (auto &tcur : ts) {
    	tcur.join();
    } 

    for (int i = 0; i < 10; i++) {
        ts3.push_back(
            thread(task3, i, std::ref(my_mutex)));
    } 

    for (auto &tcur : ts3) {
        tcur.join();
    } 

    for (int i = 0; i < 10; i++) {
        ts4.push_back(
            thread(task4, i, std::ref(my_mutex)));
    } 

    for (auto &tcur : ts4) {
        tcur.join();
    } 

    return 0;
}
