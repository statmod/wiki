// detached.cpp
/*g++ -O2 -Wall --std=c++14 -pthread -o detached detached.cpp*/
#include <string>
#include <iostream>
#include <thread>
#include <vector>

using namespace std;

void task1(string msg, int count)
{
    for (int i = 0; i < count; i++)
        cout << "task1 says: " + msg + "\n";
}

int main()
{
    thread t1(task1, "Hello", 1);
    t1.join();
    //{
    //thread t3(task1, "non-detached", 1000);
    //error!
    //}

    {
        thread t2(task1, "Detached", 1000);
        t2.detach();
    }
    return 0;
}
