// wo_mutex.cpp
/*g++ -O2 -Wall --std=c++14 -pthread -o wo_mutex wo_mutex.cpp*/
#include <string>
#include <iostream>
#include <thread>
#include <vector>

using namespace std;

// The function we want to execute 
//on the new thread.
void task1(string msg)
{
    cout << "task1 says: " << msg << "\n";
}

void task2(int i)
{
    cout << "task2 says: " << i << "~" 
    << this_thread::get_id() << "\n";
}

int main()
{
    // Constructs the new thread and runs it. 
    //Does not block execution.
    thread t1(task1, "Hello");

    // Makes the main thread wait for the 
    // new thread to finish execution, therefore 
    //blocks its own execution.
    t1.join();
    vector<thread> ts;
    for (int i = 0; i < 10; i++) {
    	ts.push_back(thread(task2, i));
    } 

    for (auto &tcur : ts) {
    	tcur.join();
    } 

    return 0;
}
