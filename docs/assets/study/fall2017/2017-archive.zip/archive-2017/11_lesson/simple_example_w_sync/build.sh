g++-7 -O2 -Wall --std=c++14 -pthread -o wo_mutex wo_mutex.cpp
g++-7 -O2 -Wall --std=c++14 -pthread -o detached detached.cpp
