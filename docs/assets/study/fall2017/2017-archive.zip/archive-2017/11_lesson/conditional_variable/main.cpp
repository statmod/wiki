#include <iostream>
#include <thread>
#include <functional>
#include <mutex>
#include <condition_variable>
using namespace std::placeholders;
class Application
{
  std::mutex m_mutex;
  std::mutex cout_mutex;

  std::condition_variable m_condVar;
  bool m_bDataLoaded;

  void say_to_cout(std::string msg) {
    std::lock_guard<std::mutex> lockGuard(cout_mutex);
    std::cout << msg;
  }

public:
  Application()
  {
    m_bDataLoaded = false;
  }


  void loadData()
  {
   // Make This Thread sleep for 1 Second
   std::this_thread::sleep_for(
    std::chrono::milliseconds(1000));
   say_to_cout("Loading Data from XML\n");
   // Lock The Data structure
   std::lock_guard<std::mutex> guard(m_mutex);
   // Set the flag to true, means data is loaded
   m_bDataLoaded = true;
   // Notify the condition variable
   m_condVar.notify_one();
  }
  bool isDataLoaded()
  {
    return m_bDataLoaded;
  }
  void mainTask()
  {
    for (int i = 0; i < 3; i++) {
      say_to_cout("Do Some Handshaking work...\n");
      std::this_thread::sleep_for(std::chrono::milliseconds(500));
    }
    // Acquire the lock
    std::unique_lock<std::mutex> mlock(m_mutex);
    // Start waiting for the Condition Variable to get signaled
    // Wait() will internally release the lock and make the thread to block
    // As soon as condition variable get signaled, resume the thread and
    // again acquire the lock. Then check if condition is met or not
    // If condition is met then continue else again go in wait.
    m_condVar.wait(mlock, std::bind(&Application::isDataLoaded, this));
    say_to_cout("Do Processing On loaded Data\n");
  }
};
int main()
{
   Application app;
   std::thread thread_1(&Application::mainTask, &app);
   std::thread thread_2(&Application::loadData, &app);

   thread_2.detach(); //thread_2.join() also possible
   thread_1.join();
   
   return 0;
}