#include <string>
#include <iostream>
#include <thread>
#include <vector>
#include <mutex>
#include <memory>
#include <sstream>
#include <future>

using namespace std;
using namespace std::placeholders;

mutex cout_mutex;
void say_to_cout(string msg) {
  lock_guard<mutex> lockGuard(cout_mutex);
  cout << msg;
}
// The function we want to execute on the new thread.

int async_task(int i, string& hello)
{
  {
    stringstream msg;
    msg << hello << " computing " << i << endl; 
    say_to_cout(msg.str());
  }
  this_thread::sleep_for(
    chrono::milliseconds(2000));
  {
    stringstream msg;
    msg << "computing done: " << 2 * i << endl; 
    say_to_cout(msg.str());
  }
  return 2*i;
}

void async_task_promise(std::promise<int>& prom, 
  int i, string& hello) {
  prom.set_value(async_task(i, hello));
}

int main()
{
  {
    string hello = "Hello!";
    auto future_obj = async(async_task, 5, ref(hello));
    for (int i = 0; i < 3; i++) {
      this_thread::sleep_for(chrono::milliseconds(300));
      {
        stringstream msg;
        msg << "doing other things..." << endl; 
        say_to_cout(msg.str());
      }
    }
    {
      stringstream msg;
      msg << "got future: " 
      << future_obj.get() << endl; 
      say_to_cout(msg.str());
    }        
  }

  {
    string hello = "Hello! Packaged task";
    packaged_task<int(int, string&)> task(async_task);
    future<int> future_obj = task.get_future();
    std::thread trd(std::move(task), 5, ref(hello));
    for (int i = 0; i < 3; i++) {
      this_thread::sleep_for(chrono::milliseconds(300));
      {
        stringstream msg;
        msg << "doing other things..." << endl; 
        say_to_cout(msg.str());
      }
    }
    {
      stringstream msg;
      msg << "got future: " 
      << future_obj.get() << endl; 
      say_to_cout(msg.str());
    }
    trd.detach(); //trd.join() also possible
  }

  {
    string hello = "Hello! Promise task";
    std::promise<int> prom;
    future<int> future_obj = prom.get_future();
    std::thread trd(bind(
      async_task_promise, _1, 5, ref(hello)), 
      ref(prom));
    for (int i = 0; i < 3; i++) {
      this_thread::sleep_for(
        chrono::milliseconds(300));
      {
        stringstream msg;
        msg << "doing other things..." << endl; 
        say_to_cout(msg.str());
      }
    }
    {
      stringstream msg;
      msg << "got future: "
       << future_obj.get() << endl; 
      say_to_cout(msg.str());
    }
    trd.detach(); //trd.join() also possible
  }
  return 0;
}
