g++ -O2 -Wall --std=c++14 -pthread -o example main.cpp
