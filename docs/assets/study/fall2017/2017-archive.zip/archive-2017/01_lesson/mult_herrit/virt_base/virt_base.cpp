// virt_base.cpp : Defines the entry point for the console application.
//

#include <string>
#include <iostream>
using namespace std;

class Location{
	int x;
	int y;
public:
	void move(int _x, int _y) {x=_x; y=_y;}
	Location(int _x, int _y): x(_x), y(_y){} 
};

class Circle: public Location{
	int r;
public:
	Circle(int _r, int _x, int _y): Location(_x,_y), r(_r){}
};

class Message: public Location{
	string s;
public:
	Message(string _s, int _x, int _y): Location(_x,_y), s(_s){}
};

class MessageInCircle: public Circle, public Message {
public:
	MessageInCircle(string _s, int _r, int _x, int _y): Circle(_r, _x, _y), Message(_s, _x, _y) {}
};

int main(int argc, char* argv[])
{
	MessageInCircle mc("you", 10, 100,100);
	mc.Circle::move(200,200);
	mc.Message::move(200,200);
}

//class Location{
//	int x;
//	int y;
//public:
//	void move(int _x, int _y) {x=_x; y=_y;}
//	Location(int _x, int _y): x(_x), y(_y){} 
//};
//
//class Circle: virtual public Location{
//	int r;
//public:
//	Circle(int _r, int _x, int _y): Location(_x,_y), r(_r){}
//};
//
//class Message: virtual public Location{
//	string s;
//public:
//	Message(string _s, int _x, int _y): Location(_x,_y), s(_s){}
//};
//
//class MessageInCircle: public Circle, public Message {
//public:
//	MessageInCircle(string _s, int _r, int _x, int _y): Location(_x, _y), Circle(_r, _x, _y), Message(_s, _x, _y) {}
//};
//
//int main(int argc, char* argv[])
//{
//	MessageInCircle mc("you", 10, 100,100);
//	mc.move(200,200);
//}
