g++-7 -Wall -O2 -o multherr multherr.cpp
