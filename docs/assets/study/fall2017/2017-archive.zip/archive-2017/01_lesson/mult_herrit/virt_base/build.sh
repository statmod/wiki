g++-7 -Wall -O2 -o virt_base virt_base.cpp
