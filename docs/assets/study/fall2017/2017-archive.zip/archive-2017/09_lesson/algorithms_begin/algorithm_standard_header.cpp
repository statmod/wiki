// algorithm standard header
		// TEMPLATE FUNCTION for_each
template<class _InIt, class _Fn1> inline
	_Fn1 for_each(_InIt _First, _InIt _Last, _Fn1 _Func)
	{	// perform function for each element
	for (; _First != _Last; ++_First) _Func(*_First);
	return (_Func);
	}
		// TEMPLATE FUNCTION find
template<class _InIt, class _Ty> inline
	_InIt find(_InIt _First, _InIt _Last, const _Ty& _Val)
	{	// find first matching _Val
	for (; _First != _Last; ++_First)
		if (*_First == _Val) break;
	return (_First);
	}
		// TEMPLATE FUNCTION find_if
template<class _InIt, class _Pr> inline
	_InIt find_if(_InIt _First, _InIt _Last, _Pr _Pred)
	{	// find first satisfying _Pred
	for (; _First != _Last; ++_First)
		if (_Pred(*_First)) break;
	return (_First);
	}
		// TEMPLATE FUNCTION adjacent_find
template<class _FwdIt> inline
	_FwdIt adjacent_find(_FwdIt _First, _FwdIt _Last)
	{	// find first matching successor
	for (_FwdIt _Firstb; (_Firstb = _First) != _Last && ++_First != _Last; )
		if (*_Firstb == *_First) return (_Firstb);
	return (_Last);
	}
		// TEMPLATE FUNCTION adjacent_find WITH PRED
template<class _FwdIt, class _Pr> inline
	_FwdIt adjacent_find(_FwdIt _First, _FwdIt _Last, _Pr _Pred)
	{	// find first satisfying _Pred with successor
	for (_FwdIt _Firstb; (_Firstb = _First) != _Last && ++_First != _Last; )
		if (_Pred(*_Firstb, *_First)) return (_Firstb);
	return (_Last);
	}
		// TEMPLATE FUNCTION transform WITH UNARY OP
template<class _InIt, class _OutIt, class _Fn1> inline
	_OutIt transform(_InIt _First, _InIt _Last, _OutIt _Dest, _Fn1 _Func)
	{	// transform [_First, _Last) with _Func
	for (; _First != _Last; ++_First, ++_Dest)
		*_Dest = _Func(*_First);
	return (_Dest);
	}
		// TEMPLATE FUNCTION transform WITH BINARY OP
template<class _InIt1, class _InIt2, class _OutIt, class _Fn2> inline
	_OutIt transform(_InIt1 _First1, _InIt1 _Last1, _InIt2 _First2, _OutIt _Dest, _Fn2 _Func)
	{	// transform [_First1, _Last1) and [_First2, _Last2) with _Func
	for (; _First1 != _Last1; ++_First1, ++_First2, ++_Dest)
		*_Dest = _Func(*_First1, *_First2);
	return (_Dest);
	}
// TEMPLATE FUNCTION replace
template<class _FwdIt, class _Ty> inline
	void replace(_FwdIt _First, _FwdIt _Last, const _Ty& _Oldval, const _Ty& _Newval)
	{	// replace each matching _Oldval with _Newval
	for (; _First != _Last; ++_First)
		if (*_First == _Oldval)
			*_First = _Newval;
	}
		// TEMPLATE FUNCTION replace_if
template<class _FwdIt, class _Pr, class _Ty> inline
	void replace_if(_FwdIt _First, _FwdIt _Last, _Pr _Pred, const _Ty& _Val)
	{	// replace each satisfying _Pred with _Val
	for (; _First != _Last; ++_First)
		if (_Pred(*_First))
			*_First = _Val;
	}
		// TEMPLATE FUNCTION replace_copy
template<class _InIt, class _OutIt, class _Ty> inline
	_OutIt replace_copy(_InIt _First, _InIt _Last, _OutIt _Dest, const _Ty& _Oldval, const _Ty& _Newval)
	{	// copy replacing each matching _Oldval with _Newval
	for (; _First != _Last; ++_First, ++_Dest)
		*_Dest = *_First == _Oldval ? _Newval : *_First;
	return (_Dest);
	}
		// TEMPLATE FUNCTION replace_copy_if
template<class _InIt, class _OutIt, class _Pr, class _Ty> inline
	_OutIt replace_copy_if(_InIt _First, _InIt _Last, _OutIt _Dest, _Pr _Pred, const _Ty& _Val)
	{	// copy replacing each satisfying _Pred with _Val
	for (; _First != _Last; ++_First, ++_Dest)
		*_Dest = _Pred(*_First) ? _Val : *_First;
	return (_Dest);
	}
		// TEMPLATE FUNCTION generate
template<class _FwdIt, class _Fn0> inline
	void generate(_FwdIt _First, _FwdIt _Last, _Fn0 _Func)
	{	// replace [_First, _Last) with _Func()
	for (; _First != _Last; ++_First) *_First = _Func();
	}
		// TEMPLATE FUNCTION generate_n
template<class _OutIt, class _Diff, class _Fn0> inline
	void generate_n(_OutIt _Dest, _Diff _Count, _Fn0 _Func)
	{	// replace [_Dest, _Dest + _Count) with _Func()
	for (; 0 < _Count; --_Count, ++_Dest) *_Dest = _Func();
	}
		// TEMPLATE FUNCTION remove_copy
template<class _InIt,
	class _OutIt,
	class _Ty> inline
	_OutIt remove_copy(_InIt _First, _InIt _Last, _OutIt _Dest, const _Ty& _Val)
	{	// copy omitting each matching _Val
	for (; _First != _Last; ++_First)
		if (!(*_First == _Val)) *_Dest++ = *_First;
	return (_Dest);
	}
// TEMPLATE FUNCTION remove_copy_if
template<class _InIt, class _OutIt, class _Pr> inline
	_OutIt remove_copy_if(_InIt _First, _InIt _Last, _OutIt _Dest, _Pr _Pred)
	{	// copy omitting each element satisfying _Pred
	for (; _First != _Last; ++_First)
		if (!_Pred(*_First)) *_Dest++ = *_First;
	return (_Dest);
	}
		// TEMPLATE FUNCTION unique
template<class _FwdIt> inline
	_FwdIt unique(_FwdIt _First, _FwdIt _Last)
	{	// remove each matching previous
	for (_FwdIt _Firstb; (_Firstb = _First) != _Last && ++_First != _Last; )
		if (*_Firstb == *_First)
			{	// copy down
			for (; ++_First != _Last; )
				if (!(*_Firstb == *_First)) *++_Firstb = *_First;
			return (++_Firstb);
			}
	return (_Last);
	}
		// TEMPLATE FUNCTION unique WITH PRED
template<class _FwdIt, class _Pr> inline
	_FwdIt unique(_FwdIt _First, _FwdIt _Last, _Pr _Pred)
	{	// remove each satisfying _Pred with previous
	for (_FwdIt _Firstb; (_Firstb = _First) != _Last && ++_First != _Last; )
		if (_Pred(*_Firstb, *_First))
			{	// copy down
			for (; ++_First != _Last; )
				if (!_Pred(*_Firstb, *_First)) *++_Firstb = *_First;
			return (++_Firstb);
			}
	return (_Last);
	}