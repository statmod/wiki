// Exceptions clean up objects
#include <fstream>
#include <exception>
#include <cstring>
using namespace std;
ofstream out("cleanup.out");

class Noisy {
  static int i;
  int objnum;
  static const int sz = 40;
  char name[sz];
public:
  Noisy(const char* nm="array elem") {
    objnum = i++;
    memset(name, 0, sz);
    strncpy(name, nm, sz - 1);
    out << "constructing Noisy " << objnum
    << " name [" << name << "]" << endl;
    if(objnum == 5) throw int(5);
    if(*nm == 'p') throw int(10);
    if(*nm == 'z') throw char('z');
  }
  ~Noisy() {
    out << "destructing Noisy " << objnum
    << " name [" << name << "]" << endl;
  }
  static void* operator new[](size_t sz) {
    out << "Noisy::new[]" << endl;
    return ::operator new(sz);
  }

  static void operator delete[](void* p) {
    out << "Noisy::delete[]" << endl;
    ::operator delete[](p);
  }
};

class NoexceptTest {
public:
  NoexceptTest() noexcept {
    throw int(10);
  } 
};

int Noisy::i = 0;

void my_terminate() {
  out << "Geez, uncaught exception" << endl;
  abort();
}

int main() {
  set_terminate(my_terminate);
  try {
    Noisy n1("before array");
    // Throws exception:
    Noisy* array = new Noisy[7];
    Noisy n2("after array");
  } catch(int i) {
    out << "caught " << i << endl;
  }
  out << "testing uncaught exception" << endl;

  // try {
  //   Noisy n3("p");
  //   Noisy n5("Final one");
  //   Noisy n4("z");
  // } catch(char c) {
  //   out << "caught " << c << endl;
  // }
  out << "testing noexcept" << endl;
  try {
    NoexceptTest A;
  } catch(...) {
    out << "Caught some exception" << endl;
  }
  return 0;
}
