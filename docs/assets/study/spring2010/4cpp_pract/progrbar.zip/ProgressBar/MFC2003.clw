; CLW file contains information for the MFC ClassWizard

[General Info]
Version=1
LastClass=CMFC2003App
LastTemplate=CFrameWnd
NewFileInclude1=#include "stdafx.h"
NewFileInclude2=#include "mfc2003.h"
LastPage=0

ClassCount=10
Class1=CAddDoc
Class2=CAddView
Class3=CChildFrame
Class4=CMainFrame
Class5=CMFC2003App
Class6=CAboutDlg
Class7=CMFC2003Doc
Class8=CMFC2003View

ResourceCount=4
Resource1=IDR_ADDTYPE
Resource2=IDD_ABOUTBOX (English (U.S.))
Class9=New
Resource3=IDR_MAINFRAME (English (U.S.))
Class10=aaa
Resource4=IDR_MFC200TYPE (English (U.S.))

[CLS:CAddDoc]
Type=0
BaseClass=CDocument
HeaderFile=AddDoc.h
ImplementationFile=AddDoc.cpp

[CLS:CAddView]
Type=0
BaseClass=CView
HeaderFile=AddView.h
ImplementationFile=AddView.cpp

[CLS:CChildFrame]
Type=0
BaseClass=CMDIChildWnd
HeaderFile=ChildFrm.h
ImplementationFile=ChildFrm.cpp

[CLS:CMainFrame]
Type=0
BaseClass=CMDIFrameWnd
HeaderFile=MainFrm.h
ImplementationFile=MainFrm.cpp
LastObject=ID_FILE_NEW2
Filter=T
VirtualFilter=fWC

[CLS:CMFC2003App]
Type=0
BaseClass=CWinApp
HeaderFile=MFC2003.h
ImplementationFile=MFC2003.cpp
Filter=N
VirtualFilter=AC

[CLS:CAboutDlg]
Type=0
BaseClass=CDialog
HeaderFile=MFC2003.cpp
ImplementationFile=MFC2003.cpp
LastObject=ID_FILE_NEW

[CLS:CMFC2003Doc]
Type=0
BaseClass=CDocument
HeaderFile=MFC2003Doc.h
ImplementationFile=MFC2003Doc.cpp
Filter=N
VirtualFilter=DC
LastObject=ID_FILE_NEW

[CLS:CMFC2003View]
Type=0
BaseClass=CView
HeaderFile=MFC2003View.h
ImplementationFile=MFC2003View.cpp

[DLG:IDD_ABOUTBOX]
Type=1
Class=CAboutDlg

[MNU:IDR_MFC200TYPE (English (U.S.))]
Type=1
Class=?
Command1=ID_FILE_NEW
Command2=ID_FILE_NEW2
Command3=ID_FILE_PRINT_SETUP
Command4=ID_FILE_MRU_FILE1
Command5=ID_APP_EXIT
Command6=ID_EDIT_UNDO
Command7=ID_EDIT_CUT
Command8=ID_EDIT_COPY
Command9=ID_EDIT_PASTE
Command10=ID_VIEW_TOOLBAR
Command11=ID_VIEW_STATUS_BAR
Command12=ID_WINDOW_NEW
Command13=ID_WINDOW_CASCADE
Command14=ID_WINDOW_TILE_HORZ
Command15=ID_WINDOW_ARRANGE
Command16=ID_APP_ABOUT
Command17=ID_PROGRESS
CommandCount=17

[MNU:IDR_MAINFRAME (English (U.S.))]
Type=1
Class=CMainFrame
Command1=ID_FILE_NEW
Command2=ID_FILE_NEW2
Command3=ID_FILE_PRINT_SETUP
Command4=ID_FILE_MRU_FILE1
Command5=ID_APP_EXIT
Command6=ID_FILE_NEW
Command7=ID_FILE_NEW2
Command8=ID_FILE_PRINT_SETUP
Command9=ID_FILE_MRU_FILE1
Command10=ID_APP_EXIT
Command11=ID_VIEW_TOOLBAR
Command12=ID_VIEW_STATUS_BAR
Command13=ID_APP_ABOUT
CommandCount=13

[TB:IDR_MAINFRAME (English (U.S.))]
Type=1
Class=?
Command1=ID_FILE_NEW
Command2=ID_FILE_OPEN
Command3=ID_FILE_SAVE
Command4=ID_EDIT_CUT
Command5=ID_EDIT_COPY
Command6=ID_EDIT_PASTE
Command7=ID_FILE_PRINT
Command8=ID_APP_ABOUT
CommandCount=8

[ACL:IDR_MAINFRAME (English (U.S.))]
Type=1
Class=?
Command1=ID_FILE_NEW
Command2=ID_FILE_OPEN
Command3=ID_FILE_SAVE
Command4=ID_FILE_PRINT
Command5=ID_EDIT_UNDO
Command6=ID_EDIT_CUT
Command7=ID_EDIT_COPY
Command8=ID_EDIT_PASTE
Command9=ID_EDIT_UNDO
Command10=ID_EDIT_CUT
Command11=ID_EDIT_COPY
Command12=ID_EDIT_PASTE
Command13=ID_NEXT_PANE
Command14=ID_PREV_PANE
CommandCount=14

[DLG:IDD_ABOUTBOX (English (U.S.))]
Type=1
Class=?
ControlCount=4
Control1=IDC_STATIC,static,1342177283
Control2=IDC_STATIC,static,1342308480
Control3=IDC_STATIC,static,1342308352
Control4=IDOK,button,1342373889

[CLS:New]
Type=0
HeaderFile=New.h
ImplementationFile=New.cpp
BaseClass=CFrameWnd
Filter=T
LastObject=ID_FILE_NEW

[MNU:IDR_ADDTYPE]
Type=1
Class=CMFC2003Doc
Command1=ID_FILE_NEW
Command2=ID_FILE_NEW2
Command3=ID_FILE_PRINT_SETUP
Command4=ID_FILE_MRU_FILE1
Command5=ID_APP_EXIT
Command6=ID_HELP
Command7=ID_PROGRESS
CommandCount=7

[CLS:aaa]
Type=0
HeaderFile=aaa.h
ImplementationFile=aaa.cpp
BaseClass=CFrameWnd
Filter=T

