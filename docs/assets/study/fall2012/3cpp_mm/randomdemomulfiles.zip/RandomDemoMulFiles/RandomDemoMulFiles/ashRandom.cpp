#include "ashRandom.h"
#include <ctime>

namespace ashRandom {
  std::random_device rd;
  std::mt19937 gen_eng(rd.entropy() ? rd() : (unsigned long)(std::time(nullptr)));
  //Or just "std::mt19937 generator(SOME_CONST);" for repeated sequence. Try it!

  double genAlpha() {
    static std::uniform_real_distribution<double> unif_real_01(0.0, 1.0);
    return unif_real_01(gen_eng);
  }
}
