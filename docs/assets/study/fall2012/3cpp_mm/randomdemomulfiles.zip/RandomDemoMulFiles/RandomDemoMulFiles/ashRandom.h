#pragma once

#include <random>

namespace ashRandom {
  extern std::mt19937 gen_eng;

  double genAlpha();
}
