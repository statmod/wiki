#include <iostream>
#include "ashRandom.h"

int main() {
  std::cout << ashRandom::genAlpha() << std::endl;
  std::uniform_int_distribution<int> dice_distribution(1, 6);

  std::cout << dice_distribution(ashRandom::gen_eng) << std::endl;
}
