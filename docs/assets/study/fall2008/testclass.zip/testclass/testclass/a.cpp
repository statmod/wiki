#include <iostream>
using namespace std;


class A {
	int x;
public:
	void hello();
};

void A::hello() {
	cout << x;
}

