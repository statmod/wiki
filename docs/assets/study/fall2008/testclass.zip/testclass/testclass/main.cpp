#include <iostream>
using namespace std;


class A {
	char a[4];

public:
	A() {
		a[0] = 0;
		a[1] = 0;
		a[2] = 0;
		a[3] = 1;
	}
	void hello();
};


void main() {
	A a;
	a.hello();
}