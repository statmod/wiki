// testdocView.h : interface of the CtestdocView class
//


#pragma once


class CtestdocView : public CScrollView
{
protected: // create from serialization only
	CtestdocView();
	DECLARE_DYNCREATE(CtestdocView)

// Attributes
public:
	CtestdocDoc* GetDocument() const;

// Operations
public:

// Overrides
public:
	virtual void OnDraw(CDC* pDC);  // overridden to draw this view
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
protected:

// Implementation
public:
	virtual ~CtestdocView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
protected:
	virtual void OnUpdate(CView* /*pSender*/, LPARAM /*lHint*/, CObject* /*pHint*/);
};

#ifndef _DEBUG  // debug version in testdocView.cpp
inline CtestdocDoc* CtestdocView::GetDocument() const
   { return reinterpret_cast<CtestdocDoc*>(m_pDocument); }
#endif

