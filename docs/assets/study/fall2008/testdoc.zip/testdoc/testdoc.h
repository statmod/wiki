// testdoc.h : main header file for the testdoc application
//
#pragma once

#ifndef __AFXWIN_H__
	#error "include 'stdafx.h' before including this file for PCH"
#endif

#include "resource.h"       // main symbols


// CtestdocApp:
// See testdoc.cpp for the implementation of this class
//

class CtestdocApp : public CWinApp
{
public:
	CtestdocApp();


// Overrides
public:
	virtual BOOL InitInstance();

// Implementation
	afx_msg void OnAppAbout();
	DECLARE_MESSAGE_MAP()
};

extern CtestdocApp theApp;