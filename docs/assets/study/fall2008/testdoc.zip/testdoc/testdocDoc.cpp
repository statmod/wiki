// testdocDoc.cpp : implementation of the CtestdocDoc class
//

#include "stdafx.h"
#include "testdoc.h"


#include "testdocDoc.h"

#include "Dialog1.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CtestdocDoc

IMPLEMENT_DYNCREATE(CtestdocDoc, CDocument)

BEGIN_MESSAGE_MAP(CtestdocDoc, CDocument)
	ON_COMMAND(ID_SETSIZES, &CtestdocDoc::OnSetsizes)
END_MESSAGE_MAP()


// CtestdocDoc construction/destruction

CtestdocDoc::CtestdocDoc() : m_r(10,10, 400, 400)
{
	// TODO: add one-time construction code here

}

CtestdocDoc::~CtestdocDoc()
{
}

BOOL CtestdocDoc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;

	// TODO: add reinitialization code here
	// (SDI documents will reuse this document)

	return TRUE;
}




// CtestdocDoc serialization

void CtestdocDoc::Serialize(CArchive& ar)
{
	if (ar.IsStoring())
	{
		// TODO: add storing code here
	}
	else
	{
		// TODO: add loading code here
	}
}


// CtestdocDoc diagnostics

#ifdef _DEBUG
void CtestdocDoc::AssertValid() const
{
	CDocument::AssertValid();
}

void CtestdocDoc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG


// CtestdocDoc commands

void CtestdocDoc::OnSetsizes()
{
	CDialog1 d;

	d.m_left = m_r.left;
	if (d.DoModal() == IDOK) {
		m_r.left = d.m_left;
		UpdateAllViews(NULL);
	}
	// TODO: Add your command handler code here
}
