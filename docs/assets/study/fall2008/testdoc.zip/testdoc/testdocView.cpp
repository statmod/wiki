// testdocView.cpp : implementation of the CtestdocView class
//

#include "stdafx.h"
#include "testdoc.h"

#include "testdocDoc.h"
#include "testdocView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CtestdocView

IMPLEMENT_DYNCREATE(CtestdocView, CScrollView)

BEGIN_MESSAGE_MAP(CtestdocView, CScrollView)
	ON_WM_LBUTTONDOWN()
END_MESSAGE_MAP()

// CtestdocView construction/destruction

CtestdocView::CtestdocView()
{
	// TODO: add construction code here

}

CtestdocView::~CtestdocView()
{
}

BOOL CtestdocView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return CView::PreCreateWindow(cs);
}

// CtestdocView drawing

void CtestdocView::OnDraw(CDC* pDC)
{
	CtestdocDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	if (!pDoc)
		return;


	pDC->Rectangle(pDoc->m_r);
	// TODO: add draw code for native data here
}


// CtestdocView diagnostics

#ifdef _DEBUG
void CtestdocView::AssertValid() const
{
	CView::AssertValid();
}

void CtestdocView::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}

CtestdocDoc* CtestdocView::GetDocument() const // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CtestdocDoc)));
	return (CtestdocDoc*)m_pDocument;
}
#endif //_DEBUG


// CtestdocView message handlers

void CtestdocView::OnLButtonDown(UINT nFlags, CPoint point)
{
	GetDocument()->m_r.top += 20;
	GetDocument()->m_r.bottom += 20;

	CString s;
	s.Format("%i, %i", point.x, point.y);
    MessageBox(s);
	

	GetDocument()->UpdateAllViews(NULL);
	// TODO: Add your message handler code here and/or call default

	CView::OnLButtonDown(nFlags, point);
}

void CtestdocView::OnUpdate(CView* pSender, LPARAM lHint, CObject* pHint)
{
    SetScrollSizes(MM_TEXT, CSize(max(GetDocument()->m_r.left,GetDocument()->m_r.right), max(GetDocument()->m_r.top,GetDocument()->m_r.bottom)));

	CView::OnUpdate(pSender, lHint, pHint);
	// TODO: Add your specialized code here and/or call the base class
}
