// testdocDoc.h : interface of the CtestdocDoc class
//


#pragma once
#include "atltypes.h"


class CtestdocDoc : public CDocument
{
protected: // create from serialization only
	CtestdocDoc();
	DECLARE_DYNCREATE(CtestdocDoc)

// Attributes
public:

// Operations
public:

// Overrides
public:
	virtual BOOL OnNewDocument();
	virtual void Serialize(CArchive& ar);

// Implementation
public:
	virtual ~CtestdocDoc();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	DECLARE_MESSAGE_MAP()
public:
	CRect m_r;
public:
	afx_msg void OnSetsizes();
};


