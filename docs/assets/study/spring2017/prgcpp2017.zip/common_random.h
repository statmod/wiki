#ifndef COMMON_RANDOM_H
#define COMMON_RANDOM_H
#include <random>

static std::mt19937 mersennetwister; //Different generator for each file!

class SingletonGenerator {
	static std::mt19937 mersennetwister;
public:
	static std::mt19937& get_mt();
};

#endif //COMMON_RANDOM_H