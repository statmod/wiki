#include <iostream>
#include "common_random.h"
#include "foreign_file.h"

// std::mt19937 SingletonGenerator::mersennetwister;

int main() {
	mersennetwister.seed(123);
	SingletonGenerator::get_mt().seed(456);

	for (int i = 0; i < 20; ++i) {
		std::cout << i << " " << mersennetwister() << " " << 
		SingletonGenerator::get_mt()() << std::endl;
	}

	std::cout << "------" << std::endl;
	mersennetwister.seed(123);
	SingletonGenerator::get_mt().seed(456);

	for (int i = 0; i < 7; ++i) {
		std::cout << i << " " << getu01_ref() << " " << getnorm_sing() << std::endl;
	}
	std::cout << "Compare with first row:" << std::endl;

	std::cout << " " << mersennetwister() << " " << 
	SingletonGenerator::get_mt()() << std::endl;

	return 0;
}