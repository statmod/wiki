g++ -c common_random.cpp -o common_random.o
g++ -c foreign_file.cpp -o foreign_file.o
g++ -c main.cpp -o main.o
g++ common_random.o foreign_file.o main.o -o example