#include "foreign_file.h"
#include "common_random.h"
#include <random>

double getu01_ref() {
	std::uniform_real_distribution<double> unif_real_01(0.0, 1.0);
	return unif_real_01(mersennetwister);
}

double getnorm_sing() {
	std::uniform_real_distribution<double> unif_real_01(0.0, 1.0);
    return unif_real_01(SingletonGenerator::get_mt());
}