#include "common_random.h"

//std::mt19937 SingletonGenerator::mersennetwister; <- WRONG
std::mt19937 SingletonGenerator::mersennetwister;


std::mt19937& SingletonGenerator::get_mt() {
	return mersennetwister;
}