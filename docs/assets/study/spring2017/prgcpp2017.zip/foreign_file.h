#ifndef FOREIGN_FILE_H
#define FOREIGN_FILE_H

double getu01_ref();
double getnorm_sing();

#endif //FOREIGN_FILE_H