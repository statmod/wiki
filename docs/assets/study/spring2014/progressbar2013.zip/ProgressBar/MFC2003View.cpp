// MFC2003View.cpp : implementation of the CMFC2003View class
//

#include "stdafx.h"
#include "MFC2003.h"

#include "MFC2003Doc.h"
#include "MFC2003View.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CMFC2003View

IMPLEMENT_DYNCREATE(CMFC2003View, CView)

BEGIN_MESSAGE_MAP(CMFC2003View, CView)
	//{{AFX_MSG_MAP(CMFC2003View)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG_MAP
	// Standard printing commands
	ON_COMMAND(ID_FILE_PRINT, CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_DIRECT, CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, CView::OnFilePrintPreview)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMFC2003View construction/destruction

CMFC2003View::CMFC2003View()
{
	// TODO: add construction code here

}

CMFC2003View::~CMFC2003View()
{
}

BOOL CMFC2003View::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return CView::PreCreateWindow(cs);
}

/////////////////////////////////////////////////////////////////////////////
// CMFC2003View drawing

void CMFC2003View::OnDraw(CDC* pDC)
{
	CMFC2003Doc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	// TODO: add draw code for native data here
}

/////////////////////////////////////////////////////////////////////////////
// CMFC2003View printing

BOOL CMFC2003View::OnPreparePrinting(CPrintInfo* pInfo)
{
	// default preparation
	return DoPreparePrinting(pInfo);
}

void CMFC2003View::OnBeginPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add extra initialization before printing
}

void CMFC2003View::OnEndPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add cleanup after printing
}

/////////////////////////////////////////////////////////////////////////////
// CMFC2003View diagnostics

#ifdef _DEBUG
void CMFC2003View::AssertValid() const
{
	CView::AssertValid();
}

void CMFC2003View::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}

CMFC2003Doc* CMFC2003View::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CMFC2003Doc)));
	return (CMFC2003Doc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CMFC2003View message handlers
