// AddDoc.cpp : implementation file
//

#include "stdafx.h"
#include "MFC2003.h"
#include "AddDoc.h"
#include "WinProgressApp.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CAddDoc

IMPLEMENT_DYNCREATE(CAddDoc, CDocument)

CAddDoc::CAddDoc()
{
}

BOOL CAddDoc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;


	return TRUE;
}

CAddDoc::~CAddDoc()
{
}


BEGIN_MESSAGE_MAP(CAddDoc, CDocument)
	//{{AFX_MSG_MAP(CAddDoc)
		// NOTE - the ClassWizard will add and remove mapping macros here.
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CAddDoc diagnostics

#ifdef _DEBUG
void CAddDoc::AssertValid() const
{
	CDocument::AssertValid();
}

void CAddDoc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CAddDoc serialization

void CAddDoc::Serialize(CArchive& ar)
{
	if (ar.IsStoring())
	{
		// TODO: add storing code here
	}
	else
	{
		// TODO: add loading code here
	}
}

/////////////////////////////////////////////////////////////////////////////
// CAddDoc commands
