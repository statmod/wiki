// MFC2003Doc.cpp : implementation of the CMFC2003Doc class
//

#include "stdafx.h"
#include "MFC2003.h"

#include "MFC2003Doc.h"
#include "WinProgressApp.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CMFC2003Doc

IMPLEMENT_DYNCREATE(CMFC2003Doc, CDocument)

BEGIN_MESSAGE_MAP(CMFC2003Doc, CDocument)
	//{{AFX_MSG_MAP(CMFC2003Doc)
	ON_COMMAND(ID_PROGRESS, OnProgress)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMFC2003Doc construction/destruction

CMFC2003Doc::CMFC2003Doc()
{
	// TODO: add one-time construction code here

}

CMFC2003Doc::~CMFC2003Doc()
{
}

BOOL CMFC2003Doc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;

	// TODO: add reinitialization code here
	// (SDI documents will reuse this document)

	return TRUE;
}



/////////////////////////////////////////////////////////////////////////////
// CMFC2003Doc serialization

void CMFC2003Doc::Serialize(CArchive& ar)
{
	if (ar.IsStoring())
	{
		// TODO: add storing code here
	}
	else
	{
		// TODO: add loading code here
	}
}

/////////////////////////////////////////////////////////////////////////////
// CMFC2003Doc diagnostics

#ifdef _DEBUG
void CMFC2003Doc::AssertValid() const
{
	CDocument::AssertValid();
}

void CMFC2003Doc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CMFC2003Doc commands

void CMFC2003Doc::OnProgress() 
{
	// TODO: Add your command handler code here


	CWinProgressApp* pApp = (CWinProgressApp*)AfxGetApp();
	pApp->SetProgressRange( 0, 100 );
	pApp->ShowProgress();
	pApp->IncrementProgressBar();
	pApp->IncrementProgressBar();

	pApp->IncrementProgressBar();

	AfxMessageBox("That's all");
	pApp->ShowProgress(FALSE);
}
