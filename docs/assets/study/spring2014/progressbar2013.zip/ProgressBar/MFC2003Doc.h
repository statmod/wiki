// MFC2003Doc.h : interface of the CMFC2003Doc class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_MFC2003DOC_H__54D1C220_1230_4D92_892D_511E77DA06AC__INCLUDED_)
#define AFX_MFC2003DOC_H__54D1C220_1230_4D92_892D_511E77DA06AC__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


class CMFC2003Doc : public CDocument
{
protected: // create from serialization only
	CMFC2003Doc();
	DECLARE_DYNCREATE(CMFC2003Doc)

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMFC2003Doc)
	public:
	virtual BOOL OnNewDocument();
	virtual void Serialize(CArchive& ar);
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CMFC2003Doc();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CMFC2003Doc)
	afx_msg void OnProgress();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MFC2003DOC_H__54D1C220_1230_4D92_892D_511E77DA06AC__INCLUDED_)
