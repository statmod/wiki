// MFC2003View.h : interface of the CMFC2003View class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_MFC2003VIEW_H__16543E60_2A3E_4654_8834_E3A6D8CDC985__INCLUDED_)
#define AFX_MFC2003VIEW_H__16543E60_2A3E_4654_8834_E3A6D8CDC985__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


class CMFC2003View : public CView
{
protected: // create from serialization only
	CMFC2003View();
	DECLARE_DYNCREATE(CMFC2003View)

// Attributes
public:
	CMFC2003Doc* GetDocument();

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMFC2003View)
	public:
	virtual void OnDraw(CDC* pDC);  // overridden to draw this view
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	protected:
	virtual BOOL OnPreparePrinting(CPrintInfo* pInfo);
	virtual void OnBeginPrinting(CDC* pDC, CPrintInfo* pInfo);
	virtual void OnEndPrinting(CDC* pDC, CPrintInfo* pInfo);
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CMFC2003View();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CMFC2003View)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

#ifndef _DEBUG  // debug version in MFC2003View.cpp
inline CMFC2003Doc* CMFC2003View::GetDocument()
   { return (CMFC2003Doc*)m_pDocument; }
#endif

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MFC2003VIEW_H__16543E60_2A3E_4654_8834_E3A6D8CDC985__INCLUDED_)
