#if !defined(AFX_NEW_H__365C5AB7_78F6_4D31_98A6_A07FE86D38C6__INCLUDED_)
#define AFX_NEW_H__365C5AB7_78F6_4D31_98A6_A07FE86D38C6__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// New.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// New frame

class New : public CFrameWnd
{
	DECLARE_DYNCREATE(New)
protected:
	New();           // protected constructor used by dynamic creation

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(New)
	public:
	virtual void OnFinalRelease();
	//}}AFX_VIRTUAL

// Implementation
protected:
	virtual ~New();

	// Generated message map functions
	//{{AFX_MSG(New)
		// NOTE - the ClassWizard will add and remove member functions here.
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
	// Generated OLE dispatch map functions
	//{{AFX_DISPATCH(New)
		// NOTE - the ClassWizard will add and remove member functions here.
	//}}AFX_DISPATCH
	DECLARE_DISPATCH_MAP()
	DECLARE_INTERFACE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_NEW_H__365C5AB7_78F6_4D31_98A6_A07FE86D38C6__INCLUDED_)
