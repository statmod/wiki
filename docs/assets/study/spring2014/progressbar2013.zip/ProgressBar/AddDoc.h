#if !defined(AFX_ADDDOC_H__D7C19466_94EC_4067_AD7C_566FB53674CF__INCLUDED_)
#define AFX_ADDDOC_H__D7C19466_94EC_4067_AD7C_566FB53674CF__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// AddDoc.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CAddDoc document

class CAddDoc : public CDocument
{
protected:
	CAddDoc();           // protected constructor used by dynamic creation
	DECLARE_DYNCREATE(CAddDoc)

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAddDoc)
	public:
	virtual void Serialize(CArchive& ar);   // overridden for document i/o
	protected:
	virtual BOOL OnNewDocument();
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CAddDoc();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

	// Generated message map functions
protected:
	//{{AFX_MSG(CAddDoc)
		// NOTE - the ClassWizard will add and remove member functions here.
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_ADDDOC_H__D7C19466_94EC_4067_AD7C_566FB53674CF__INCLUDED_)
