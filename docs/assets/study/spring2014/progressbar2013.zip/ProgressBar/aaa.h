#if !defined(AFX_AAA_H__9C2CB6E7_556E_4D19_B220_398D9CD3AC91__INCLUDED_)
#define AFX_AAA_H__9C2CB6E7_556E_4D19_B220_398D9CD3AC91__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// aaa.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// aaa frame

class aaa : public CFrameWnd
{
	DECLARE_DYNCREATE(aaa)
protected:
	aaa();           // protected constructor used by dynamic creation

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(aaa)
	//}}AFX_VIRTUAL

// Implementation
protected:
	virtual ~aaa();

	// Generated message map functions
	//{{AFX_MSG(aaa)
		// NOTE - the ClassWizard will add and remove member functions here.
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_AAA_H__9C2CB6E7_556E_4D19_B220_398D9CD3AC91__INCLUDED_)
