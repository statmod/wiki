// New.cpp : implementation file
//

#include "stdafx.h"
#include "mfc2003.h"
#include "New.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// New

IMPLEMENT_DYNCREATE(New, CFrameWnd)

New::New()
{
	EnableAutomation();
}

New::~New()
{
}

void New::OnFinalRelease()
{
	// When the last reference for an automation object is released
	// OnFinalRelease is called.  The base class will automatically
	// deletes the object.  Add additional cleanup required for your
	// object before calling the base class.

	CFrameWnd::OnFinalRelease();
}


BEGIN_MESSAGE_MAP(New, CFrameWnd)
	//{{AFX_MSG_MAP(New)
		// NOTE - the ClassWizard will add and remove mapping macros here.
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

BEGIN_DISPATCH_MAP(New, CFrameWnd)
	//{{AFX_DISPATCH_MAP(New)
		// NOTE - the ClassWizard will add and remove mapping macros here.
	//}}AFX_DISPATCH_MAP
END_DISPATCH_MAP()

// Note: we add support for IID_INew to support typesafe binding
//  from VBA.  This IID must match the GUID that is attached to the 
//  dispinterface in the .ODL file.

// {095AEE24-3FA2-450F-9FCA-8E67ED615BC8}
static const IID IID_INew =
{ 0x95aee24, 0x3fa2, 0x450f, { 0x9f, 0xca, 0x8e, 0x67, 0xed, 0x61, 0x5b, 0xc8 } };

BEGIN_INTERFACE_MAP(New, CFrameWnd)
	INTERFACE_PART(New, IID_INew, Dispatch)
END_INTERFACE_MAP()

/////////////////////////////////////////////////////////////////////////////
// New message handlers
