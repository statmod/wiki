// AddView.cpp : implementation file
//

#include "stdafx.h"
#include "MFC2003.h"
#include "AddView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CAddView

IMPLEMENT_DYNCREATE(CAddView, CView)

CAddView::CAddView()
{
}

CAddView::~CAddView()
{
}


BEGIN_MESSAGE_MAP(CAddView, CView)
	//{{AFX_MSG_MAP(CAddView)
		// NOTE - the ClassWizard will add and remove mapping macros here.
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CAddView drawing

void CAddView::OnDraw(CDC* pDC)
{
	CDocument* pDoc = GetDocument();
	// TODO: add draw code here
}

/////////////////////////////////////////////////////////////////////////////
// CAddView diagnostics

#ifdef _DEBUG
void CAddView::AssertValid() const
{
	CView::AssertValid();
}

void CAddView::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}
CAddDoc* CAddView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CAddDoc)));
	return (CAddDoc*)m_pDocument;
}

#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CAddView message handlers
