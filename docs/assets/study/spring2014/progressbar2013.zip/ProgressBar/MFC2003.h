// MFC2003.h : main header file for the MFC2003 application
//

#if !defined(AFX_MFC2003_H__2B1C334C_A5BC_401C_B4BA_6A8743C55741__INCLUDED_)
#define AFX_MFC2003_H__2B1C334C_A5BC_401C_B4BA_6A8743C55741__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"       // main symbols
#include "WinProgressApp.h"

/////////////////////////////////////////////////////////////////////////////
// CMFC2003App:
// See MFC2003.cpp for the implementation of this class
//

class CMFC2003App : public CWinProgressApp
{
public:
	CMFC2003App();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMFC2003App)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation
	//{{AFX_MSG(CMFC2003App)
	afx_msg void OnAppAbout();
	afx_msg void OnFileNew();
	afx_msg void OnFileNew2();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
	protected:
	virtual CWnd* GetProgressParentWnd();
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MFC2003_H__2B1C334C_A5BC_401C_B4BA_6A8743C55741__INCLUDED_)
