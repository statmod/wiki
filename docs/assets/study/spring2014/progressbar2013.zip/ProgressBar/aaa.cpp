// aaa.cpp : implementation file
//

#include "stdafx.h"
#include "mfc2003.h"
#include "aaa.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// aaa

IMPLEMENT_DYNCREATE(aaa, CFrameWnd)

aaa::aaa()
{
}

aaa::~aaa()
{
}


BEGIN_MESSAGE_MAP(aaa, CFrameWnd)
	//{{AFX_MSG_MAP(aaa)
		// NOTE - the ClassWizard will add and remove mapping macros here.
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// aaa message handlers
