#if !defined(AFX_ADDVIEW_H__CB987F88_A4C1_4505_803F_9C52C6FFE6C5__INCLUDED_)
#define AFX_ADDVIEW_H__CB987F88_A4C1_4505_803F_9C52C6FFE6C5__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// AddView.h : header file
//

#include "AddDoc.h"

/////////////////////////////////////////////////////////////////////////////
// CAddView view

class CAddView : public CView
{
protected:
	CAddView();           // protected constructor used by dynamic creation
	DECLARE_DYNCREATE(CAddView)

// Attributes
public:

	CAddDoc* GetDocument();

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAddView)
	protected:
	virtual void OnDraw(CDC* pDC);      // overridden to draw this view
	//}}AFX_VIRTUAL

// Implementation
protected:
	virtual ~CAddView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

	// Generated message map functions
protected:
	//{{AFX_MSG(CAddView)
		// NOTE - the ClassWizard will add and remove member functions here.
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


#ifndef _DEBUG  // debug version in MFC2003View.cpp
inline CAddDoc* CAddView::GetDocument()
   { return (CAddDoc*)m_pDocument; }
#endif

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_ADDVIEW_H__CB987F88_A4C1_4505_803F_9C52C6FFE6C5__INCLUDED_)
