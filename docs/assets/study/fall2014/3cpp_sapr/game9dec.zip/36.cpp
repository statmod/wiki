void YYY(int *b, int *e) {
auto len = size_t(e - b);
auto buf0 = new int[len]; //TODO Use only one buffer
auto buf1 = new int[len];
size_t len0{0}, len1{0};
for (int mask = 1; mask; mask <<= 1) {
for(auto p = b; p < e; ++p) {
if (*p & mask) {
buf1[len1++] = *p;
} else {
buf0[len0++] = *p;
}
}
memcpy(b, buf0, len0); // TODO Get rid off extra copying
memcpy(b + len0, buf1, len1);
}
}
int main() {
int a[] = {4, 2, 1, 2, 3, 5, 1, 11, 33, 4};
YYY(a, a + sizeof(a) / sizeof(a[0]));
for (auto e : a) {
printf("%d ", e);
}
return 0;
}
