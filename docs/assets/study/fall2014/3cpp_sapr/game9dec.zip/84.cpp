void ZZZ(int *b, int *e) {
if (e - b <= 1) return;
int med = *b; // Use the proper value (and var name)
auto bb = b, ee = e - 1;
while (bb <= ee) {
while (*bb < med) ++bb;
while (*ee > med) --ee;
if (bb <= ee) std::swap(*bb, *ee);
}
ZZZ(b, ee + 1);
ZZZ(bb, e);
}
int main() {
int a[] = {4, 2, 1, 2, 3, 5, 1, 11, 33, 4};
ZZZ(a, a + sizeof(a) / sizeof(a[0]));
printf("\n");
for (auto e : a) {
printf("%d ", e);
}
return 0;
}
