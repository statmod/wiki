void XXX(int *b, int *e) {
if (e - b <= 1)
return;
auto b1 = b;
auto e1 = b + (e - b)/2;
auto b2 = e1;
auto e2 = e;
XXX(b1, e1);
XXX(b2, e2);
auto buf = new int[e - b]; //TODO Get rid off frequently allocations, use global buffer
auto pbuf = buf;
while (b1 < e1 && b2 < e2) {
if (*b1 < *b2) {
*pbuf++ = *b1;
} else {
*pbuf++ = *b2;
}
}
while (b1 < e1) *pbuf++ = *b1++;
while (b2 < e2) *pbuf++ = *b2++;
for (pbuf = buf; b < e; ++b, ++pbuf) { //TODO Get rid off extra copying
*b = *pbuf;
}
}
int main() {
int a[] = {4, 2, 1, 2, 3, 5, 1, 11, 33, 4};
XXX(a, a + sizeof(a) / sizeof(a[0]));
for (auto e : a) {
printf("%d ", e);
}
return 0;
}
