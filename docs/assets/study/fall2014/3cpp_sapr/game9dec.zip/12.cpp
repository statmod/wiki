void XXX(size_t index, int *b, int *e) {
if (b + 2*index + 2 == e) {
if (b[index] < b[2*index + 1]) {
std::swap(b[index], b[2*index + 1]);
XXX(2*index + 1, b, e); // TODO Get rid of recursion
}
} else { // TODO Merge two branches
size_t i = b[2*index + 1] > b[2*index + 2] ? 1 : 2;
if (b[index] < b[2*index + i]) {
std::swap(b[index], b[2*index + i]);
XXX(2*index + i, b, e);
}
}
}
void YYY(int *b, int *e) {
auto len = size_t(e - b);
if (len <= 1) return;
for (size_t i = len - 1; i >= 0; --i) XXX(i, b, e); // TODO Use more optimal algo
while (b < e) {
std::swap(*b, *e);
--e;
XXX(0, b, e);
}
}
int main() {
int a[] = {4, 2, 1, 2, 3, 5, 1, 11, 33, 4};
YYY(a, a + sizeof(a) / sizeof(a[0]));
printf("\n");
for (auto e : a) {
printf("%d ", e);
}
return 0;
}
