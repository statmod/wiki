// ChildView.cpp : implementation of the CChildView class
//

#include "stdafx.h"
#include "test.h"
#include "ChildView.h"

//#include "LineDialog.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CChildView

CChildView::CChildView()
: m_press_point(566,239)
, m_mouse_over(false)
, m_line_width(1)
{
  m_pen1.CreatePen(PS_SOLID, 
    m_line_width * 1, RGB(0, 0, 0));
 
  CMetaFileDC mdc; 
  mdc.CreateEnhanced(NULL, NULL, NULL, NULL);

  drawFigure(&mdc);
  m_hEmf = mdc.CloseEnhanced();

  mdc.CreateEnhanced(NULL, "picture.emf", NULL, NULL);
  drawFigure(&mdc);
  mdc.CloseEnhanced();
  
}

CChildView::~CChildView()
{
}


BEGIN_MESSAGE_MAP(CChildView, CWnd)
	ON_WM_PAINT()
	ON_WM_LBUTTONDOWN()
	ON_WM_MOUSEMOVE()
END_MESSAGE_MAP()



// CChildView message handlers

BOOL CChildView::PreCreateWindow(CREATESTRUCT& cs) 
{
	if (!CWnd::PreCreateWindow(cs))
		return FALSE;

	cs.dwExStyle |= WS_EX_CLIENTEDGE;
	cs.style &= ~WS_BORDER;
	cs.lpszClass = AfxRegisterWndClass(CS_HREDRAW|CS_VREDRAW|CS_DBLCLKS, 
		::LoadCursor(NULL, IDC_ARROW), reinterpret_cast<HBRUSH>(COLOR_WINDOW+1), NULL);

	return TRUE;
}

void CChildView::OnPaint() 
{
	CPaintDC dc(this); 

  dc.PlayMetaFile(m_hEmf, 
    CRect(m_press_point.x - 50, m_press_point.y - 50, 
    m_press_point.x + 50, m_press_point.y + 50));
//  drawFigure(&dc);
}


void CChildView::OnLButtonDown(UINT nFlags, CPoint point)
{
	// TODO: Add your message handler code here and/or call default
	m_press_point = point;
	Invalidate();

	CWnd::OnLButtonDown(nFlags, point);
}

void CChildView::OnMouseMove(UINT nFlags, CPoint point)
{
	bool state = (point.x - m_press_point.x) * (point.x - m_press_point.x) +
			(point.y - m_press_point.y) * (point.y - m_press_point.y) <= 2500;

	if (m_mouse_over != state) {
		m_mouse_over = state;
		Invalidate();
	}

	CWnd::OnMouseMove(nFlags, point);
}





void CChildView::drawFigure(CDC * pDC)
{
	CPen  *oldpen;
  oldpen = pDC->SelectObject(&m_pen1);
	pDC->Ellipse(m_press_point.x - 50, m_press_point.y - 50,
		       m_press_point.x + 50, m_press_point.y + 50);

  pDC->MoveTo(m_press_point.x - 35, m_press_point.y - 35);
  pDC->LineTo(m_press_point.x + 35, m_press_point.y + 35);
  pDC->MoveTo(m_press_point.x - 35, m_press_point.y + 35);
  pDC->LineTo(m_press_point.x + 35, m_press_point.y - 35);
	pDC->SelectObject(oldpen);

}
