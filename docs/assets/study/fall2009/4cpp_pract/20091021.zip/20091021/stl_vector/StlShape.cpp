// StlShape.cpp - corrected 20/10/2009: Defines the entry point for the console application.

#include "stdafx.h"
#include <vector>
#include <deque>
#include <list>
#include <iostream>
using namespace std;

class Circle
{
	static int counter;
public:
	int i;
	int j;
  void draw() { cout << i <<' '<<j<< " Circle::draw\n"; }
  Circle() { j=0; i= (++counter); cout << i <<' '<<j<<" Circle\n";}
  Circle(int a) { j=a; i= (++counter); cout << i <<' '<<j<<" Circle(int)\n";}
  Circle (const Circle& c) { j=c.j; i= (++counter);cout << i <<' '<<j<<" Circle&\n"; }
  Circle& operator = (const Circle& c) {i=c.i; j=c.j; cout << "operator=\n"; return *this;}
  ~Circle() { cout << i <<' '<<j<<"~Circle\n"; }
};


int Circle::counter=0;

//typedef std::deque<Circle> Container;
typedef std::vector<Circle> Container;
//typedef std::list<Circle> Container;
typedef Container::iterator Iter;

void main() {
	{
  Container shapes;  shapes.reserve(3);
  for (int iii=0; iii<3; iii++)
	  shapes.push_back(Circle((iii+1)*10));
  
  for(Iter i = shapes.begin();
      i != shapes.end(); i++)
    (*i).draw();
	}
	cout<<endl<<"***********************"<<endl;
	{
  Container shapes;
  for (int iii=0; iii<3; iii++)
	  shapes.push_back(Circle((iii+1)*10));
  
  for(Iter i = shapes.begin();
      i != shapes.end(); i++)
    (*i).draw();
	}
		cout<<endl<<"***********************"<<endl;
	{
  Container shapes(3);
  for (int iii=0; iii<3; iii++)
	  shapes[iii]=Circle((iii+1)*10);
  
  for(Iter i = shapes.begin();
      i != shapes.end(); i++)
    (*i).draw();
	}
} ///:~

/*
Vector:
  Container shapes;
  for (int iii=0; iii<3; iii++)
	  shapes.push_back(Circle((iii+1)*10));
1 10 Circle(int)
2 10 Circle&
1 10~Circle
3 20 Circle(int)
4 10 Circle&
5 20 Circle&
2 10~Circle
3 20~Circle
6 30 Circle(int)
7 10 Circle&
8 20 Circle&
9 30 Circle&
4 10~Circle
5 20~Circle
6 30~Circle
7 10 Circle::draw
8 20 Circle::draw
9 30 Circle::draw
7 10~Circle
8 20~Circle
9 30~Circle

  Container shapes;  shapes.reserve(3);
  for (int iii=0; iii<3; iii++)
	  shapes.push_back(Circle((iii+1)*10));
1 10 Circle(int)
2 10 Circle&
1 10~Circle
3 20 Circle(int)
4 20 Circle&
3 20~Circle
5 30 Circle(int)
6 30 Circle&
5 30~Circle
2 10 Circle::draw
4 20 Circle::draw
6 30 Circle::draw
2 10~Circle
4 20~Circle
6 30~Circle

  Container shapes(3);
  for (int iii=0; iii<3; iii++)
	  shapes[iii]=Circle((iii+1)*10);
19 0 Circle
20 0 Circle&
21 0 Circle&
22 0 Circle&
19 0~Circle
23 10 Circle(int)
operator=
23 10~Circle
24 20 Circle(int)
operator=
24 20~Circle
25 30 Circle(int)
operator=
25 30~Circle
23 10 Circle::draw
24 20 Circle::draw
25 30 Circle::draw
23 10~Circle
24 20~Circle
25 30~Circle

Deque, List:
  Container shapes;
  for (int iii=0; iii<3; iii++)
	  shapes.push_back(Circle((iii+1)*10));
1 10 Circle(int)
2 10 Circle&
1 10~Circle
3 20 Circle(int)
4 20 Circle&
3 20~Circle
5 30 Circle(int)
6 30 Circle&
5 30~Circle
2 10 Circle::draw
4 20 Circle::draw
6 30 Circle::draw
2 10~Circle
4 20~Circle
6 30~Circle
*/