// virt_copy.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <iostream>
using namespace std;

class A {
	int a;
public:
	A(int _a=1):a(_a){}
	virtual int f(){return a;};
	virtual A* create(){return new A();}
	virtual A* copy(){A* ppa = new A(*this); return ppa;}
};
class B: public A{
	int b;
public:
	B(int _a=1, int _b=2):A(_a),b(_b){}
	virtual int f(){return b;};
	virtual B* create(){return new B();}
	virtual B* copy(){B* ppb = new B(*this); return ppb;}
};

int _tmain(int argc, _TCHAR* argv[])
{
	A* ab1=new B(10,20);

	A* ab2=ab1->create();

	A* ab3=ab1->copy();
	
	cout<<"ab1 "<<ab1->f()<<endl;
	cout<<"create ab2 "<<ab2->f()<<endl;
	cout<<"copy   ab3 "<<ab3->f()<<endl;

	return 0;
}

