// templ_class.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <string>
#include <iostream>
using namespace std;

template<typename T, typename C>
int compare (const basic_string<T>&str1, const basic_string<T>&str2)
{
	for(int i=0; i<str1.length()&& i<str2.length();++i)
		if(!C::eq(str1[i], str2[i])) return C::lt(str1[i],str2[i])?-1:1;
	return str1.length()-str2.length();
}

template<typename T> class Cmp{
public:
	static int eq(T a, T b){return a==b;}
	static int lt(T a, T b){return a<b;}
};

int _tmain(int argc, _TCHAR* argv[])
{
	basic_string<char> s1("abcd"), s2("abce");
	cout<< compare<char,Cmp<char> >(s1,s2);
	return 0;
}

