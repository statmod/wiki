#pragma once

#include <vector>
using namespace std;

namespace my_space {

struct Point {
  int x, y;
};

class Polygon
{
  vector<Point> my_v;
public:
  Polygon(void);

  int getPointsNum() {
    return (int)my_v.size();
  }
  Point getPoint( int i );
  void appendPoint( int x, int y );
  void clearPoly() {
    my_v.clear();
  }
public:
  virtual ~Polygon(void);
};

};