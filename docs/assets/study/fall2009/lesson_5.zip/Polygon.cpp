#include "Polygon.h"

namespace my_space {

Point Polygon::getPoint( int i ) {
  Point p = { -1,-1 };

  if (i >= 0 && i < getPointsNum()) {
    p = my_v[i];
  }

  return p;
}
void Polygon::appendPoint( int x, int y ) {
  Point p = { x, y };
  my_v.push_back(p);
}






Polygon::Polygon(void) {
  
}

Polygon::~Polygon(void)
{
}
}