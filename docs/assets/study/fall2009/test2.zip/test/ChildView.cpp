// ChildView.cpp : implementation of the CChildView class
//

#include "stdafx.h"
#include "test.h"
#include "ChildView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CChildView

CChildView::CChildView()
: m_press_point(0)
, m_mouse_over(false)
, m_draw_thickline(false)
{
}

CChildView::~CChildView()
{
}


BEGIN_MESSAGE_MAP(CChildView, CWnd)
	ON_WM_PAINT()
	ON_WM_LBUTTONDOWN()
	ON_WM_MOUSEMOVE()
	ON_COMMAND(ID_DRAW_THICKLINE, &CChildView::OnDrawThickline)
	ON_UPDATE_COMMAND_UI(ID_DRAW_THICKLINE, &CChildView::OnUpdateDrawThickline)
END_MESSAGE_MAP()



// CChildView message handlers

BOOL CChildView::PreCreateWindow(CREATESTRUCT& cs) 
{
	if (!CWnd::PreCreateWindow(cs))
		return FALSE;

	cs.dwExStyle |= WS_EX_CLIENTEDGE;
	cs.style &= ~WS_BORDER;
	cs.lpszClass = AfxRegisterWndClass(CS_HREDRAW|CS_VREDRAW|CS_DBLCLKS, 
		::LoadCursor(NULL, IDC_ARROW), reinterpret_cast<HBRUSH>(COLOR_WINDOW+1), NULL);

	return TRUE;
}

void CChildView::OnPaint() 
{
	CPaintDC dc(this); 
	
	CPen bpen, *oldpen;
	bpen.CreatePen(PS_DASH, 5 * (m_draw_thickline ? 2 : 1), RGB(m_mouse_over ? 255 : 0, 0, 0));
    oldpen = dc.SelectObject(&bpen);
	dc.Ellipse(m_press_point.x - 50, m_press_point.y - 50,
		       m_press_point.x + 50, m_press_point.y + 50);
	dc.SelectObject(oldpen);
}


void CChildView::OnLButtonDown(UINT nFlags, CPoint point)
{
	// TODO: Add your message handler code here and/or call default
	m_press_point = point;
	Invalidate();

	CWnd::OnLButtonDown(nFlags, point);
}

void CChildView::OnMouseMove(UINT nFlags, CPoint point)
{
	bool state = (point.x - m_press_point.x) * (point.x - m_press_point.x) +
			(point.y - m_press_point.y) * (point.y - m_press_point.y) <= 2500;

	if (m_mouse_over != state) {
		m_mouse_over = state;
		Invalidate();
	}

	CWnd::OnMouseMove(nFlags, point);
}


void CChildView::OnDrawThickline()
{
	m_draw_thickline = !m_draw_thickline;
	Invalidate();
}


void CChildView::OnUpdateDrawThickline(CCmdUI *pCmdUI)
{
	pCmdUI->SetCheck(m_draw_thickline);
}
