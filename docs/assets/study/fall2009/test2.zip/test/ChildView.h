// ChildView.h : interface of the CChildView class
//


#pragma once
#include "atltypes.h"


// CChildView window

class CChildView : public CWnd
{
// Construction
public:
	CChildView();

// Attributes
public:

// Operations
public:

// Overrides
	protected:
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);

// Implementation
public:
	virtual ~CChildView();

	// Generated message map functions
protected:
	afx_msg void OnPaint();
	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);

public:
	CPoint m_press_point;
public:
	bool m_mouse_over;
public:
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
public:
	afx_msg void OnDrawThickline();
public:
	bool m_draw_thickline;
public:
	afx_msg void OnUpdateDrawThickline(CCmdUI *pCmdUI);
};

