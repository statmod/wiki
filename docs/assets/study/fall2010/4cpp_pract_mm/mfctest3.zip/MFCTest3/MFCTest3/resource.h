//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by MFCTest3.rc
//
#define IDD_ABOUTBOX                    100
#define IDP_OLE_INIT_FAILED             100
#define IDR_MAINFRAME                   128
#define IDR_MFCTest3TYPE                129
#define IDD_DIALOG1                     130
#define IDC_EDIT1                       1000
#define IDC_CHECK1                      1001
#define IDC_BUTTON_AIISMSM              1002
#define IDC_RADIO1                      1003
#define IDC_RADIO2                      1004
#define IDC_RADIO3                      1005
#define IDC_RADIO4                      1006
#define ID_MYMENU_MYPOS                 32771
#define ID_BUTTON32772                  32772
#define ID_BUTTON_CROSS                 32772

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        131
#define _APS_NEXT_COMMAND_VALUE         32773
#define _APS_NEXT_CONTROL_VALUE         1007
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
