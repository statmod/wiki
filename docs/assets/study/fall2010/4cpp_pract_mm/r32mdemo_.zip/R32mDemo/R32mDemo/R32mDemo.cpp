// R32mDemo.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"

#include "r32m.h"
#include <ctime>

#include <iostream>
using namespace std;

int getRnd(int mod){
	return (int)(mod * rnunif()) % mod;
}

int main(int argc, char* argv[]){
	rninit((unsigned long)(time()));
	//rninit(1001);
	cout << "alpha = " << rnunif() << endl;
	cout << "dice: " << getRnd(6)+1 << " points" << endl;
	return 0;
}

