// BlockAlloc.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <iostream>
using namespace std;

class Array{
	int *p;
	size_t size;
public:
	Array(size_t size = 0) : size(size){
		p = new int[size];
	}
	
	virtual ~Array(){
		delete [] p;
	}

	Array(const Array& A){
		this->size = A.size;
		this->p = new int[size];
		memcpy(this->p, A.p, size*sizeof(int));
	}

	const Array& operator=(const Array& A){
		delete [] this->p;
		this->size = A.size;
		this->p = new int[size];
		memcpy(this->p, A.p, size*sizeof(int));
	}

	size_t getSize() const{
		return size;
	}
	
	void resize(size_t newSize){
		int *tmp = new int[newSize];
		memcpy(tmp, p, std::min(size, newSize)*sizeof(int));
		delete [] p;
		p = tmp;
		size = newSize;
	}
	
	int& operator[](size_t inx){
		return p[inx];
	}

	const int& operator[](size_t inx) const{
		return p[inx];
	}
};



int main(int argc, char* argv[])
{
	Array ar;
	ar.resize(15);
	ar[0] = ar[1] = 1;
	for(int i = 2; i < 15; ++i)
		ar[i] = ar[i-1] + ar[i-2];

	cout << ar[12] << " " << ar[13] << " " << ar[14] << endl;
	ar.resize(100);
	ar.resize(3);
	cin.get();
	return 0;
}

