#include <iostream>
#include <iterator>

extern "C" {
    void DGESV(int* N, int* NRHS, double* A, int* LDA, int* IPIV, double* B, int* LDB, int* INFO );
}

int main() {
	int n = 3;
	int nr = 1;
	double a[9] = {1, 0, 0, 0, 2, 1, 0, 1, 2};
	int lda = n;
	int pivot[3];
	double b[3] = {4, 5, 6};
	int ldb = n;
	int info;

	DGESV(&n, &nr, a, &lda, pivot, b, &ldb, &info);

	std::cout << info << std::endl;
	for (auto &i : b) {
		std::cout << i << " ";
	}
	std::cout << std::endl;
	return 0;
}
