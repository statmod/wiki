#include <iostream>

extern "C" {
    double do_something(double x, int amount);
}

int main() {
	std::cout << do_something(3., 5) << std::endl;
	return 0;
}
