#include "math.h"

double do_something(double x, int amount) {
	double z = 1;
	int i;
	for (i = 0; i < amount; i++)
		z *= x;
	return z;
}
