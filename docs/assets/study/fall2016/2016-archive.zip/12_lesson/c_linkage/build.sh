gcc-6 -c -O2 -Wall -o some_obj_file.o some_code.c
g++-6 --std=c++11 -O2 -Wall -o main some_obj_file.o main.cpp