// type_traits.cpp : Defines the entry point for the console application.
//

#include <iostream>
#include <stdexcept>
//using namespace std;

template <typename T>
struct is_pod
{
    enum { value = false };
};

template <>
struct is_pod<long>
{
    enum { value = true };
};

template <>
struct is_pod<int>
{
    enum { value = true };
};

template <typename T, bool B> 
struct copy_trait
{
    static void copy( T* to, const T* from, int n)
    {
        std::cerr << "default copy with loop" << std::endl;
        
        for( int i = 0; i < n; ++i )
            to[i] = from[i];
    }
};
template <typename T> 
struct copy_trait<T, true>
{
    static void copy( T* to, const T* from, int n)
    {
        std::cerr << "bitwise copy for POD" << std::endl;
        
        memcpy( to, from, n*sizeof(T));
    }
};

template <class T, class Cpy = copy_trait<T,is_pod<T>::value> >
class matrix
{
public:
    matrix( int i, int j );
    matrix( const matrix &other);
    ~matrix();
    matrix& operator=( const matrix &other);

    int rows() const { return x; }
    int cols() const { return y; }

    T& at( int i, int j);
    const T&  at( int i, int j) const;
    T& operator()( int i, int j);
    const T&  operator()( int i, int j) const;

    void check (int i, int j) const;
    
    matrix& operator+=( const matrix &other);
private:
    int  x;
    int  y;
    T   *v;
    void copy( const matrix &other);
};

template <class T, class Cpy>
 matrix<T,Cpy> operator+( const matrix<T,Cpy> &x, const matrix<T,Cpy> &y);
           

template <class T, class Cpy>
 matrix<T,Cpy>::matrix( int i, int j)
{
    x = i; 
    y = j;
    v = new T[x*y];
}
template <class T, class Cpy>
 matrix<T,Cpy>::matrix( const matrix &other)
{
    copy( other);
}
template <class T, class Cpy>
 matrix<T,Cpy>::~matrix()
{
    delete [] v;
}
template <class T, class Cpy>
 matrix<T,Cpy>& matrix<T,Cpy>::operator=( const matrix &other)
{
    if ( this != &other )
    {
        delete [] v;
        copy( other);
    }
    return *this;
}

template <class T, class Cpy>
void matrix<T,Cpy>::check( int i, int j) const 
{
    if ( ( 0 <= i  && i < x ) && ( 0 <= j  && j < y ) )
        /* ok */ ;
    else
        throw std::out_of_range("Error in check");
}
template <class T, class Cpy>
T& matrix<T,Cpy>::at( int i, int j) 
{
    check(i,j); 
    return operator()(i,j); 
}
template <class T, class Cpy>
const T& matrix<T,Cpy>::at( int i, int j) const 
{ 
    check(i,j); 
    return operator()(i,j); 
}
template <class T, class Cpy>
T& matrix<T,Cpy>::operator()( int i, int j)
{ 
    return v[i*y + j]; 
}
template <class T, class Cpy>
const T& matrix<T,Cpy>::operator() ( int i, int j) const 
{ 
    return v[i*y + j]; 
}
template <class T, class Cpy>
 matrix<T,Cpy>& matrix<T,Cpy>::operator+=( const matrix &other)
{
    for ( int i = 0; i < x*y; ++i )
        v[i] += other.v[i];
    return *this;
}
template <class T, class Cpy>
 matrix<T,Cpy> operator+( const matrix<T,Cpy> &x, const matrix<T,Cpy> &y)
{
    matrix<T,Cpy> temp( x );
    temp += y;
    return temp;
}

template <class T, class Cpy>
void matrix<T,Cpy>::copy( const matrix &other)
{
    x = other.x;
    y = other.y;
    v = new T[x*y];

    Cpy::copy( v, other.v, x*y);
}

int main()
{
    matrix<double, copy_trait<double, true>> m(3,4), m1(m), m2(3,4); 
    m2 = m1;
	return 0;
}

