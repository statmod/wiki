#include<iostream>
#include <iomanip>

typedef unsigned long long ull;

template <ull It> 
struct e_frac
{
    enum {nom = e_frac<It - 1>::nom * It + 1, 
          denom = e_frac<It - 1>::denom * It};
}; 

template <>
struct e_frac<0>
{ 
	enum {nom = 1, denom = 1};
};

template <ull It> 
struct e_double
{
public:
    static constexpr double value = (double)e_frac<It>::nom / e_frac<It>::denom;
};

const double e_10 = (double)e_frac<10>::nom / e_frac<10>::denom;

int main() {
    std::cout << std::setprecision(16) << e_double<20>::value << std::endl;
    std::cout << std::setprecision(8) << e_10 << std::endl; 
    return 0;
}
