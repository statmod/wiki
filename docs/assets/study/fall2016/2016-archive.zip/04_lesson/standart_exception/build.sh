g++-6 -Wall -O2 --std=c++11 -fno-elide-constructors -o standart_exception standart_exception.cpp
