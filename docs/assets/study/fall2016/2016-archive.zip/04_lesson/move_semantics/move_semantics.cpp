//g++ -Wall -O2 --std=c++11 -fno-elide-constructors -o move_semantics move_semantics.cpp

#include <iostream>

using namespace std;

class A {
public:
    int* x;
    A(int v = 0) {
        cout << "A()" << endl;
        cout << "new int(v) inside A" << endl;
        x = new int(v);
    }

    ~A() {
        //cout << "~A()" << endl;
        delete x;
    }

    A(const A& other) {
        cout << "A(A&)" << endl;
        cout << "new int(v) inside A" << endl;
        if (*other.x > 0) {
            x = new int(*other.x);
        } else
        {
            x = new int(-*other.x);
        }
        
    }

    A& operator=(const A& other) {
        cout << "A::operator=(other)" << endl;
        if (&other != this) {
        *x = *other.x;            
        }
        return *this;
    }

    A operator+(const A& other) {
        cout << "A::operator+(other)" << endl;
        return A(*x + *other.x);
    }

};

class B {
public:
    int* x;
    B(int v = 0) {
        cout << "B()" << endl;
        cout << "new int(v) inside B" << endl;
        x = new int(v);
    }

    ~B() {
        //cout << "~B()" << endl;
        delete x;
    }

    B(B&& other) {
        cout << "B(B&&)" << endl;
        x = other.x;
        if (*x < 0) *x = -*x;
        other.x = 0;
    }

    B& operator=(B other) {
        cout << "B::operator=(other)" << endl;
        swap(x, other.x);
        return *this;
    }

    B operator+(const B& other) {
        cout << "B::operator+(other)" << endl;
        return B(*x + *other.x);
    }

};

int main() {
    cout << "---nonmove2---" << endl;
    A nonmove2(-2);
    cout << "---nonmove3---" << endl;
    A nonmove3(-3);
    cout << "---nonmove5---" << endl;
    A nonmove5(nonmove2);
    cout << "---nonmove5 + ---" << endl;
    nonmove5 = nonmove2 + nonmove3;
    cout << "---nonmove5b---" << endl;
    A nonmove5b(nonmove2 + nonmove3);
    cout << *nonmove2.x << " " << *nonmove3.x << " " << *nonmove5.x << " " << *nonmove5b.x << endl;

    cout << "---move2---" << endl;
    B move2(-2);
    cout << "---move3---" << endl;
    B move3(-3);
    //B move5(move2); 
    /* error:  note: 'constexpr B::B(const B&)' is implicitly */
    /* declared as deleted because 'B' declares a move constructor or move assignment operator */

    cout << "---move5---" << endl;
    B move5;
    cout << "---move5 + ---" << endl;
    move5 = move2 + move3;
    cout << "---move5b---" << endl;
    B move5b(move2 + move3);
    cout << *move2.x << " " << *move3.x << " " << *move5.x << " " << *move5b.x << endl;

    return 0;
}
