g++-6 -Wall -O2 --std=c++11 -o array array.cpp
g++-6 -Wall -O2 --std=c++11 -o iterator iterator.cpp