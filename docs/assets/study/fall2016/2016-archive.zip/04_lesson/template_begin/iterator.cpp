#include <iostream>
using namespace std;

template <class T> class vect_iterator;

template <class T>
class vect{
private:
  friend class vect_iterator<T>;
  T* p;
  int size;
public:
  vect(int n);
  ~vect() {delete[] p;}
};

template <class T>
vect<T>::vect(int n)
{
  size=n; p=new T[n];
  for (int i=0; i<n; i++) p[i]=0;
}

template <class T>
class vect_iterator{
private:
  vect<T> * pv;
  int cur_ind;
public:
  vect_iterator(vect<T> & v, int i=0): pv(&v), cur_ind(i% v.size) {};
  bool successor();
  bool predecessor();
  T& item() {return (pv->p[cur_ind]);}
  void reset(int n=0) { cur_ind=n % pv-> size;}
  int position() {return cur_ind;}
};

template <class T>
bool vect_iterator<T>::successor()
{
  if(cur_ind >= pv-> size-1) return(false);
  else  { ++cur_ind;  return (true); }
}

template <class T>
bool vect_iterator<T>::predecessor()
{
  if(cur_ind <= 0) return(false);
  else  { --cur_ind;  return (true); }
}

int main()
{
  int n;  cout <<"Enter size: ";  cin >> n;
  cout << "\nEnter elements\n";

  vect<int> v(n);  vect_iterator<int> front1(v); vect_iterator<int> front2(v,3);

  do  cin >> front1.item();
  while (front1.successor());

  front1.reset(n+4);  cout<<endl;
  do  cout << front1.item()<< ' '<<front2.item() <<endl;
  while (front1.predecessor() && front2.successor());
  return 0;
}
