g++-6 -Wall -O2 --std=c++11 -o shared_ptr shared_ptr.cpp
g++-6 -Wall -O2 --std=c++11 -o unique_ptr unique_ptr.cpp
g++-6 -Wall -O2 --std=c++11 -o weak_ptr weak_ptr.cpp
