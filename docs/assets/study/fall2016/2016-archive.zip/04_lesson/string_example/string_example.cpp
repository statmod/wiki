#include <iostream>
#include <exception>
#include <string>
using namespace std;

int main() {
//: C01:SmallString.cpp
  string imBlank;
  string heyMom("Where are my socks?");
  string standardReply = "Beamed into deep space on wide angle dispersion?";
  string useThisOneAgain(standardReply);

//: C01:AddStrings.cpp
  string s1("This "); string s2("That ");
  string s3("The other ");
  // operator+ concatenates strings
  s1 = s1 + s2;
  cout << s1 << endl;
  // Another way to concatenates strings
  s1 += s3;
  cout << s1 << endl;
  // You can index the string on the right
  s1 += s3 + s3[4] + "oh lala";
  cout << s1 << endl;

//: C01:StringReplace.cpp
  string s("A piece of text"); string tag("$tag$");
  s.insert(8, tag + ' ');
  cout << s << endl;
  size_t start = s.find(tag);
  cout << "start = " << start << endl; 
  cout << "size = " << tag.size() << endl;
  s.replace(start, tag.size(), "hello there");
  cout << s << endl;
  cout<< s.find("dummy") << " == " << string::npos << endl;
  cout<< string::npos + 1 << endl; //What is it?

//: Additional example
  string svim("Very important message");
  const char * str_shallow = svim.c_str();
  cout<< str_shallow << endl;

  char* str_deep =  new char[svim.size()+1];
  svim.copy(str_deep, string::npos);
  str_deep[svim.size()]=0;
  cout << str_deep << endl;
  delete[] str_deep;

  try{
    //svim[100]=' ';
    svim.at(100)=' ';
  }
  catch(exception& e){
      cout<<e.what()<<endl;
  }
}
