// templ_fun.cpp : Defines the entry point for the console application.
//

#include <iostream>
#include <cstring>
//using namespace std;
using std::cout;
using std::cin;
using std::endl;

template <typename T> 
T min (T x, T y){
	cout<<"T min ";
	return x < y ? x : y;
}

int min (int i, int j)
{
	cout<<"my min ";
	return i < j? i :j;
}

//template<> const char * min/*<const char*>*/(const char * str1, const char * str2)
//{
//	return strcmp (str1, str2)<0 ? str1 : str2;
//}

const char * min (const char * str1, const char * str2)
{
	cout<<"str min"<<endl;
	return strcmp (str1,str2)<0 ? str1 : str2;
}

template <typename T1, typename T2> 
void print (T1 x, T2 y){
	cout<< "print "<< x <<' '<< y <<endl;
}

template<typename T1, typename T2> 
void print(T1* x, T2* y)
{
	cout<< "print*  "<< x <<' '<< y <<endl;
}

template<typename T, typename U> T implicit_cast (U u) {return u;}

void g (int i)
{
	//implicit_cast(i); //cannot deduce template
	cout << implicit_cast<double>(i) << endl;;
	cout << implicit_cast<char>(i) << endl;
	cout << implicit_cast<char, int>(i+0.9) << endl;
	//implicit_cast<char*,int>(i);// no conversion from char* to int
}

int main()
{
	double z;
    z = min (2.1, 3.); cout << z << endl; //T min
	z = min (2.1, 3); cout << z << endl; //my min
	z = std::min (2.1, 3.1); cout << z << endl; // std::min
	//z = std::min (2.1, 3); // std::min - ambiguous
	z = std::min <double> (2.1, 3); cout << z << endl; // std::min

    cout<<"*****************\n";

    z = min (2, 3); cout << z << endl; //my min
	z = min (2.1, 3); cout << z << endl;  //my min
	z = std::min (2, 3); cout << z << endl; // std::min
	//z = std::min (2.1, 3); // std::min - ambiguous
	z = std::min <int> (2.1, 3); cout << z << endl; // std::min

    cout<<"*****************\n";

	const char * str1="ball", *str2 = str1 + 1;
	cout << std::min(str1, str2) << endl;
	cout << min(str1, str2) << endl; // str min
	print (2, 3.1);
	print (str1, str2);

    cout<<"*****************\n";
    g(49);
	return 0;
}
