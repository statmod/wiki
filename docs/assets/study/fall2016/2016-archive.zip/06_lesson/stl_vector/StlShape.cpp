// StlShape.cpp - corrected 20/10/2009: Defines the entry point for the console application.

#include <vector>
#include <deque>
#include <list>
#include <iostream>
using namespace std;

class Circle {
	static int counter;
public:
	int i;
	int j;
  void draw() { cout << i <<' '<<j<< " Circle::draw\n"; }
  Circle() { j=0; i= (++counter); cout << i <<' '<<j<<" Circle\n";}
  Circle(int a) { j=a; i= (++counter); cout << i <<' '<<j<<" Circle(int)\n";}
  Circle (const Circle& c) { j=c.j; i= (++counter);cout << i <<' '<<j<<" Circle&\n"; }
  Circle& operator = (const Circle& c) {i=c.i; j=c.j; cout << "operator=\n"; return *this;}
  ~Circle() { cout << i <<' '<<j<<"~Circle\n"; }
};


int Circle::counter=0;

typedef std::deque<Circle> Container;
//typedef std::vector<Circle> Container;
//typedef std::list<Circle> Container;
typedef Container::iterator Iter;

int main() {
	// {
 //  Container shapes;  shapes.reserve(3);
 //  for (int iii=0; iii<3; iii++)
	//   shapes.push_back(Circle((iii+1)*10));
  
 //  for(Iter i = shapes.begin();
 //      i != shapes.end(); i++)
 //    (*i).draw();
	// }
	// cout<<endl<<"***********************"<<endl;
	{
  Container shapes;
  for (int iii=0; iii<3; iii++)
	  shapes.push_back(Circle((iii+1)*10));
  
  for(Iter i = shapes.begin();
      i != shapes.end(); i++)
    (*i).draw();
	}
	// 	cout<<endl<<"***********************"<<endl;
	// {
 //  Container shapes(3);
 //  for (int iii=0; iii<3; iii++)
	//   shapes[iii]=Circle((iii+1)*10);
  
 //  for(Iter i = shapes.begin();
 //      i != shapes.end(); i++)
 //    (*i).draw();
	// }
} ///:~
