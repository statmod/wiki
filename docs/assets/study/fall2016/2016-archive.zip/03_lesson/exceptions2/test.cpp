#include <iostream>

using namespace std;

class SizeError{
protected:
  long size;
public:
  SizeError(long value=0) {size=value;cout<<"SE\n";}
  SizeError(const SizeError& S) {size=S.size; cout<<"SE&\n";}
  virtual ~SizeError() {cout<<"~SE\n";}
  virtual const char* ErrorMesage(){return "Unknown Size Error";}
  long Size(){return size;}
};

class TooBigSizeError: public SizeError{
public:
  TooBigSizeError(long value): SizeError(value){cout<<"TBSE\n";}
  TooBigSizeError(const TooBigSizeError& S){size=S.size; cout<<"TBSE&\n";}
  virtual ~TooBigSizeError() {cout<<"~TBSE\n";}

  virtual const char* ErrorMesage() {return "Too big size";}
};

class WrongSizeError: public SizeError{
public:
  WrongSizeError(long value): SizeError(value){}
  WrongSizeError(const WrongSizeError& S): SizeError() {}
  virtual const char* ErrorMesage() {return "Wrong Size";}
};


void WriteCacheBlock(char * data, long size)
{
  if(size> 1000)
  {
	  
	  TooBigSizeError T(size);
	  throw T;
  }
  else if(size<0)
	  throw WrongSizeError(size);
  else throw SizeError(size);
  // ...
}

int main()
{
char data[2000];
try 
{
try
  {
  WriteCacheBlock(data, 2000);
  }
catch(SizeError error)
  {
	 cout<<error.ErrorMesage()<<" - "<< error.Size() <<endl;
	 throw;
  }
}
catch(SizeError& error)
  {
	 cout<<error.ErrorMesage()<<" - "<< error.Size() <<endl;
  }

return 0;
}
