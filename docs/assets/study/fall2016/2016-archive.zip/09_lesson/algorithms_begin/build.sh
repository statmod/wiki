g++ -Wall -O2 --std=c++11 -o Manipulations Manipulations.cpp
g++ -Wall -O2 --std=c++11 -o SearchReplace SearchReplace.cpp