//: C06:ForEach.cpp {-mwcc}
// From "Thinking in C++, Volume 2", by Bruce Eckel & Chuck Allison.
// (c) 1995-2004 MindView, Inc. All Rights Reserved.
// See source code use permissions stated in the file 'License.txt',
// distributed with the code package available at www.MindView.net.
// Use of STL for_each() algorithm.
//{L} Counted
#include <algorithm>
#include <iostream>
#include <vector>
#include <iostream>
#include <string>
#include <memory>
#include <iomanip>
#include <cmath>
using namespace std;

class Counted {
  static int count;
  shared_ptr<string> ident;
public:
  Counted(shared_ptr<string> id) : ident(id) { ++count; }
  ~Counted() {
    std::cout << *ident << " count = "
              << --count << std::endl;
  }
  const string& get_ident() const {return *ident;}
};

class CountedVector : public std::vector<Counted*> {
public:
  CountedVector(shared_ptr<string> id) {
    for(int i = 0; i < 5; i++)
      push_back(new Counted(id));
  }
};

// Function object:
template<class T> class DeleteT {
public:
  void operator()(T* x) { delete x; }
};

// Template function:
template<class T> void wipe(T* x) { delete x; }

int Counted::count = 0;

int main() {
  CountedVector B(make_shared<string>("two"));
  for_each(B.begin(), B.end(), DeleteT<Counted>());
  CountedVector C(make_shared<string>("three"));
  //lambda function with void return type
  auto fun_1 = [](Counted* x) {std::cout << x -> get_ident() << " ";};
  for_each(C.begin(), C.end(), fun_1);
  int j = 10;
  //lambda function that catches j
  std::cout << std::endl;
  std::cout << std::setprecision(10) << [j](double x) {return sqrt(x + j);}(3.5) << std::endl;
  std::cout << std::setprecision(10) << [j](double x) -> float {return sqrt(x + j);}(3.5) << std::endl;

  //non-mutable lambda with two arguments
  int epic_counter = 0;
  auto fun_3 = [&epic_counter](Counted* x, string v) {//mutable {
    epic_counter++;
    std::cout << x -> get_ident() + " " + v + "; " << epic_counter;
  };
  using namespace std::placeholders;
  for_each(C.begin(), C.end(), std::bind(fun_3, _1, "hooray!"));
  std::cout << "Epic counter = " << epic_counter << std::endl;
  for_each(C.begin(), C.end(), wipe<Counted>);
} ///:~
