#include <map>
#include <iostream>
using namespace std;

#include <set>
int main ()
{
  typedef multiset<int, less<int> > mset;
  mset s;
  cout << "count (42) = " << s.count (42) << endl;
  s.insert (42);
  cout << "count (42) = " << s.count (42) << endl;
  s.insert (42);
  cout << "count (42) = " << s.count (42) << endl;

  mset::iterator i = s.find (40);

  if (i == s.end ())
    cout << "40 Not found" << endl;
  else
    cout << "Found " << *i << endl;
  i = s.find (42);
  if (i == s.end ())
    cout << "Not found" << endl;
  else
    cout << "Found " << *i << endl;
  int count = s.erase (42);
  cout << "Erased " << count << " instances" << endl;
  return 0;
}
