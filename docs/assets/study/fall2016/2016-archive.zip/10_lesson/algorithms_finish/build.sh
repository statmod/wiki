# g++ -Wall -O2 --std=c++11 -o MergeTest MergeTest.cpp
# g++ -Wall -O2 --std=c++11 -o Comparison Comparison.cpp
g++ -Wall -O2 --std=c++11 -o SortedSearchTest SortedSearchTest.cpp StreamTokenizer.cpp