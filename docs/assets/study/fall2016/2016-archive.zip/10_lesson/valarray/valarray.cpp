// valarray_eckel.cpp : Defines the entry point for the console application.
//: C07:Valarray1.cpp {-bor}
#include <iostream>
#include <valarray>
using namespace std;

template<typename T> void print(const char* lbl, const valarray<T>& a) {
  cout << lbl << ": ";
  for(size_t i = 0; i < a.size(); ++i)
    cout << a[i] << ' ';
  cout << endl;
}

double f(double x) { return 2.0 * x - 1.0; }

int main() {
  {
    double n[] = {1.0, 2.0, 3.0, 4.0};
    valarray<double> v(n, sizeof n / sizeof n[0]);
    print("v", v);
    valarray<double> sh(v.shift(1));
    print("shift 1", sh);
    valarray<double> acc(v + sh);
    print("sum", acc);
    valarray<double> trig(sin(v) + cos(acc));
    print("trig", trig);
    valarray<double> p(pow(v, 3.0));
    print("3rd power", p);
    valarray<double> app(v.apply(f));
    print("f(v)", app);
    valarray<bool> eq(v == app);
    print("v == app?", eq);
    double x = v.min();
    double y = v.max();
    double z = v.sum();
    cout << "x = " << x << ", y = " << y
      << ", z = " << z  << endl;
  }
  {
    int data[] = {1,2,3,4,5,6,7,8,9,10,11,12};
    valarray<int> v(data, 12);
    valarray<int> r1(v[slice(0, 4, 3)]);
    print("slice(0,4,3)", r1);
    // Выделение элементов по условию
    valarray<int> r2(v[v > 6]);
    print("elements > 6", r2);
    // Возведение в квадрат первого столбца
    v[slice(0, 4, 3)] *= valarray<int>(v[slice(0, 4, 3)]);
    print("after squaring first column", v);
    // Восстановление исходных значений
    int idx[] = {1,4,7,10};
    valarray<int> save(idx, 4);
    v[slice(0, 4, 3)] = save;
    print("v restored", v);
    // Выделение двухмерного подмножества: {{1, 3, 5}, {7, 9, 11}}
    valarray<size_t> siz(2);
    siz[0] = 2;
    siz[1] = 3;
    valarray<size_t> gap(2);
    gap[0] = 6;
    gap[1] = 2;
    valarray<int> r3(v[gslice(0, siz, gap)]);
    print("2-d slice", r3);
    // Выделение подмножества по логической маске (элементы bool)
    valarray<bool> mask(false, 5);
    mask[1] = mask[2] = mask[4] = true;
    valarray<int> r4(v[mask]);
    print("v[mask]", r4);
    // Выделение подмножества по индексной маске (элементы size_t)
    size_t idx2[] = {2,2,3,6};
    valarray<size_t> mask2(idx2, 4);
    valarray<int> r5(v[mask2]);
    print("v[mask2]", r5);
    // Использование индексной маски при присваивании
    valarray<char> text("now is the time", 15);
    valarray<char> caps("NITT", 4);
    valarray<size_t> idx3(4);
    idx3[0] = 0; idx3[1] = 4; idx3[2] = 7; idx3[3] = 11; text[idx3] = caps;
    print("capitalized", text);
  }
} 