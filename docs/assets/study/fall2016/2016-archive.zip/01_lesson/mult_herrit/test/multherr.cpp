#include <iostream>

using namespace std;

class A
{
protected:
  int a;
public:
  A(){cout<<endl<<"A()";}
  A(int aa){a=aa; cout<<endl<<"A(int)";}
};

class B: public A
{
protected:
  int b;
public:
  B(){cout<<endl<<"B()";}
  B(int aa):A(aa), b(a)  {b=b+1;cout<<endl<<"B(int)";}
};

class C: public A
{
public:
  C():A(){cout<<endl<<"C";}
};

class D: public B, public C
{
public:
  D():B(), C(){cout<<endl<<"D";}
  D(int a):B(a), C(){cout<<endl<<"D"<<' '<<B::a<<' '<<b;}
};

class BV: virtual public A
{
protected:
  int b;
public:
  BV():A(b), b(2){cout<<endl<<"BV";}
};

class CV: virtual public A
{
public:
  CV():A(){cout<<endl<<"CV";}
};

class DV: public BV, public CV
{
public:
  DV():BV(),CV(){cout<<endl<<"DV()";}
  DV(int aa):CV(),BV(),A(aa){cout<<endl<<"DV(int)"<<' '<<a<<' '<<b;}
};

int main()
{
  cout<<endl<<"class D";          D d;
  cout<<endl<<"class D(int)";     D di(5);
  cout<<endl<<"class DV";         DV dv;
  cout<<endl<<"class DV(int)";    DV dvi(5);
  return 0;
}
