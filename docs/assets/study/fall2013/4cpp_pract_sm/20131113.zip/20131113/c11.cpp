// c11.cpp : Defines the entry point for the console application.
//

#include <iostream>
using namespace std;

class A{
public:
	int i;
	A(int _i=0){i=_i; cout<<"A"<<endl;}
	A(const A& a){i=a.i; cout<<"A(A&)"<<endl;}
	~A(){cout<<"~A"<<endl;}
};


int main()
{   

double total = 3;
A value = 5;
cout<<"start"<<endl;

cout << [&total, value](int x) -> int {total += (x * value.i) + 0.1; return total;} (2) <<endl;
cout << total <<endl;
//cout << [&total, value](int x) {total += (x * value.i) + 0.1; return total;} (2) <<endl;
//auto pf = [&total, value](int x) {total += (x * value.i) + 0.1} (2); 
//cout<< total <<endl;

return 0;
}


//A
//start
//A(A&)
//~A
//10
//~A
