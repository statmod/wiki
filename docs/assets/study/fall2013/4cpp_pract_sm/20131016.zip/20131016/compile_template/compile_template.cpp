// compile_template.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include<iostream>

//template <unsigned long N> 
//struct binary
//{
//    static unsigned const value
//       = binary<N/10>::value * 2   // prepend higher bits
//         + N%10;                   // to lowest bit
//}; 
//
//template <>                           // specialization
//struct binary<0>                      // terminates recursion
//{
//    static unsigned const value = 0;
//};

template <unsigned long N> 
struct binary
{
    enum {value
       = binary<N/10>::value * 2   // prepend higher bits
	   + N%10};                   // to lowest bit
}; 

template <>                           // specialization
struct binary<0>                      // terminates recursion
{ 
	enum {value = 0};
};


// this class encapsulates the "+" operation.
struct plus
{
    static double apply( double a, double b)
    {
        return a+b;
    }
};


// the node in the parse tree.
template <typename Left, typename Op, typename Right>
struct X
{
    Left    left;
    Right   right;

    X( Left t1, Right t2) : left(t1), right(t2)  { }

    double operator[](int i)
    {
        return Op::apply( left[i], right[i] );
    }
};


struct Array
{
    // constructor
    Array( double *data, int N) : data_(data), N_(N) { }

    // assign an expression to the array
    template <typename Left, typename Op, typename Right>
    void operator=( X<Left,Op,Right> expr)
    {
        for ( int i = 0; i < N_; ++i)
            data_[i] = expr[i];
    }

    double operator[](int i)
    {
        return data_[i];
    }

    double *data_;
    int N_;
};


template <typename Left>
X<Left, plus, Array> operator+( Left a, Array b)
{
    return X<Left, plus, Array>(a,b);
}


int _tmain(int argc, _TCHAR* argv[])
{
	const unsigned int bi1 = binary<110011001111>::value; 
	std::cout<< bi1<<std::endl;

	double a_data[] = { 2, 3, 5, 9 };
    double b_data[] = { 1, 0, 0, 1 };
    double c_data[] = { 3, 0, 2, 5 };
    double d_data[4];

    Array A(a_data,4);
    Array B(b_data,4);
    Array C(c_data,4);
    Array D(d_data,4);

    D = A + B + C;

    for ( int i = 0; i < 4; ++i )
        std::cout << D[i] << " ";
   std::cout << std::endl;
	return 0;
}

