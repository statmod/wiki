// comboDoc.cpp : implementation of the CcomboDoc class
//

#include "stdafx.h"
#include "combo.h"

#include "comboDoc.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CcomboDoc

IMPLEMENT_DYNCREATE(CcomboDoc, CDocument)

BEGIN_MESSAGE_MAP(CcomboDoc, CDocument)
END_MESSAGE_MAP()


// CcomboDoc construction/destruction

CcomboDoc::CcomboDoc()
{
	// TODO: add one-time construction code here

}

CcomboDoc::~CcomboDoc()
{
}

BOOL CcomboDoc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;

	// TODO: add reinitialization code here
	// (SDI documents will reuse this document)

	return TRUE;
}




// CcomboDoc serialization

void CcomboDoc::Serialize(CArchive& ar)
{
	if (ar.IsStoring())
	{
		// TODO: add storing code here
	}
	else
	{
		// TODO: add loading code here
	}
}


// CcomboDoc diagnostics

#ifdef _DEBUG
void CcomboDoc::AssertValid() const
{
	CDocument::AssertValid();
}

void CcomboDoc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG


// CcomboDoc commands
