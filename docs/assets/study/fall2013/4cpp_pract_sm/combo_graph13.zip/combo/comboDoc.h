// comboDoc.h : interface of the CcomboDoc class
//


#pragma once

class CcomboDoc : public CDocument
{
protected: // create from serialization only
	CcomboDoc();
	DECLARE_DYNCREATE(CcomboDoc)

// Attributes
public:

// Operations
public:

// Overrides
	public:
	virtual BOOL OnNewDocument();
	virtual void Serialize(CArchive& ar);

// Implementation
public:
	virtual ~CcomboDoc();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	DECLARE_MESSAGE_MAP()
};


