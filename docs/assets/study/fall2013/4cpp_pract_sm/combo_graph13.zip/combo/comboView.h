// comboView.h : interface of the CcomboView class
//


#pragma once


class CcomboView : public CView
{
protected: // create from serialization only
	CcomboView();
	DECLARE_DYNCREATE(CcomboView)

// Attributes
public:
	CcomboDoc* GetDocument() const;

// Operations
public:

// Overrides
	public:
	virtual void OnDraw(CDC* pDC);  // overridden to draw this view
virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
protected:
	virtual BOOL OnPreparePrinting(CPrintInfo* pInfo);
	virtual void OnBeginPrinting(CDC* pDC, CPrintInfo* pInfo);
	virtual void OnEndPrinting(CDC* pDC, CPrintInfo* pInfo);

// Implementation
public:
	virtual ~CcomboView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	DECLARE_MESSAGE_MAP()
};

#ifndef _DEBUG  // debug version in comboView.cpp
inline CcomboDoc* CcomboView::GetDocument() const
   { return reinterpret_cast<CcomboDoc*>(m_pDocument); }
#endif

