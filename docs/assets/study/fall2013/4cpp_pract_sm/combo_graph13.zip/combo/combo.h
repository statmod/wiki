// combo.h : main header file for the combo application
//
#pragma once

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"       // main symbols


// CcomboApp:
// See combo.cpp for the implementation of this class
//

class CcomboApp : public CWinApp
{
public:
	CcomboApp();


// Overrides
public:
	virtual BOOL InitInstance();

// Implementation
	afx_msg void OnAppAbout();
	DECLARE_MESSAGE_MAP()
};

extern CcomboApp theApp;