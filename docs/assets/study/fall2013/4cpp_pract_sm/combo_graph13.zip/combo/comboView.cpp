// comboView.cpp : implementation of the CcomboView class
//

#include "stdafx.h"
#include "combo.h"

#include "comboDoc.h"
#include "comboView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CcomboView

IMPLEMENT_DYNCREATE(CcomboView, CView)

BEGIN_MESSAGE_MAP(CcomboView, CView)
	// Standard printing commands
	ON_COMMAND(ID_FILE_PRINT, CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_DIRECT, CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, CView::OnFilePrintPreview)
END_MESSAGE_MAP()

// CcomboView construction/destruction

CcomboView::CcomboView()
{
	// TODO: add construction code here

}

CcomboView::~CcomboView()
{
}

BOOL CcomboView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return CView::PreCreateWindow(cs);
}

// CcomboView drawing

void CcomboView::OnDraw(CDC* /*pDC*/)
{
	CcomboDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	if (!pDoc)
		return;

	// TODO: add draw code for native data here
}


// CcomboView printing

BOOL CcomboView::OnPreparePrinting(CPrintInfo* pInfo)
{
	// default preparation
	return DoPreparePrinting(pInfo);
}

void CcomboView::OnBeginPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add extra initialization before printing
}

void CcomboView::OnEndPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add cleanup after printing
}


// CcomboView diagnostics

#ifdef _DEBUG
void CcomboView::AssertValid() const
{
	CView::AssertValid();
}

void CcomboView::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}

CcomboDoc* CcomboView::GetDocument() const // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CcomboDoc)));
	return (CcomboDoc*)m_pDocument;
}
#endif //_DEBUG


// CcomboView message handlers
