// cleanup.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
//: C07:Nudep.cpp
// Naked pointers
#include <fstream>
#include <exception>
#include <memory>
#include <cstdlib>
using namespace std;
ofstream out("res.txt");

//class Cat {
//public:
//  Cat() { out << "Cat()" << endl; }
//  ~Cat() { out << "~Cat()" << endl; }
//};
//
//class Dog {
//public:
//  Dog() { out << "Dog()" << endl; }
//  ~Dog() { out << "~Dog()" << endl; }
//};
//
//class UseResources {
//  shared_ptr<Cat> bp;
//  shared_ptr<Dog> op;
//public:
//  UseResources(int count = 1): bp(new Cat), op(new Dog) {
//    out << "UseResources()" << endl;
//    throw int(5);
//  }
//  ~UseResources() {
//    out << "~UseResources()" << endl;
//  }
//}

class Cat {
public:
  Cat() { out << "Cat()" << endl; }
  ~Cat() { out << "~Cat()" << endl; }
};

class Dog {
public:
  Dog() { out << "Dog()" << endl; }
  ~Dog() { out << "~Dog()" << endl; }
};

class UseResources {
  Cat* bp;
  Dog* op;
public:
  UseResources(int count = 1){
    out << "UseResources()" << endl;
    bp = new Cat;
    op = new Dog;
    throw int(5);
  }
  ~UseResources() {
    out << "~UseResources()" << endl;
    delete bp;
    delete op;
  }
};

int main() {
  try {
    UseResources ur(3);
  } catch(int) {
    out << "inside handler" << endl;
  }
} ///:~
