# ������������� ��������� ��� ������ �������
period.prob.matrix <- function(period, clusters, reg,
                               range.known.obs = c(.95,1)){
  nrow <- length(clusters)
  ncol <- period
  idx.col <- sample(ncol, size = reg, rep = FALSE)
  if (nrow <= reg) {
    idx.row <- c(sample(1:nrow), 
                 sample(nrow, reg-nrow, rep = TRUE))
  } else idx.row <- sample(nrow, reg, rep = FALSE)
  prob.matrix <- sapply(1:ncol, function (i) {
    res <- numeric(nrow+1)
    indx <- which(i == idx.col)
    indx <- ifelse(length(indx) != 0, idx.row[indx], 0) + 1 	
    res[indx] <- runif(1, min = range.known.obs[1], 
                       max = range.known.obs[2])	
    res[-indx] <- runif(nrow)		
    res[-indx] <- (1-res[indx])*(res[-indx])/sum(res[-indx])	
    res
  })
  rownames(prob.matrix) <- c(0, clusters)
  colnames(prob.matrix) <- 1:period
  prob.matrix
}

# ������������������ ����������� ������ ��������, 
# ����������� �������������� ���������
move.from.matrix <- function(prob.matrix, clusters){
  sapply(1:ncol(prob.matrix), function(i){
    sample(clusters, size = 1, prob = prob.matrix[,i])
  })	
}

# ������������� �������������
gen.beh.matrix <- function(behaviours = list(list("12" = c(3,5),
                                                  "NA" = c(8,9)),
                                             list("24" = c(2), 
                                                  "NA" = c(6,7))),
                           regularity = list("12" = 3,"24" = 3, 
                                             "168" = 20),
                           range.known.obs = c(.95,1)){
  require(plyr)
  llply(behaviours, function(beh){
    periods <- names(beh)[names(beh) != "NA"]
    res <- lapply(periods, function(period){
      period.prob.matrix(period = as.numeric(period), 
                         clusters = beh[[period]], 
                         reg = regularity[[period]],
                         range.known.obs = range.known.obs)
      
    })
    names(res) <- periods
    res
  })
}

# ������������� ������ �� ��������������� ��������������
gen.data <- function(sep.val = 0.4, num.outlier = 10, junk.rate = 0.1, 
                     login.dev = 0.5, observ.period = 6, na.size = 150,
                     behaviours = list(list("24" = c(1,2),"NA" = c(4,5)),
                                       list("24" = c(3), "NA" = c(6,7))),
                     list.beh.matrix){
  require(clusterGeneration)
  num.observs <- 24*30*observ.period
  data <- data.frame(clind = numeric(0), time = numeric(0))
  start.time <- 0
  for(i in seq_along(behaviours)){
    beh <- behaviours[[i]]
    periods <- names(beh)
    for(cur.period in periods){
      cur.clusters <- beh[[cur.period]]
      if(cur.period != "NA"){
        prob.matrix <- list.beh.matrix[[i]][[cur.period]]
        nrep <- round(num.observs/as.numeric(cur.period))
        move <- as.vector(replicate(nrep, 
                                    move.from.matrix(prob.matrix,
                                                     c(0, cur.clusters))))
        length.move <- length(move)
        idx <- which(move != 0)
        n.junk <- round(length(idx)*junk.rate/(1-junk.rate))
        r.idx <- range(idx)
        junk.move <- sample(cur.clusters, n.junk, replace = TRUE) 
        move <- c(move, junk.move)
        junk.time <- runif(n.junk, min = r.idx[1], max = r.idx[2])
        time <- start.time + c(1:length.move, junk.time)
        time <- time + rnorm(length.move + n.junk, sd = login.dev)
        df <- data.frame(clind = move, time = time)
        df <- df[df$clind != 0, ]
        data <- merge(data, df, all = TRUE)
      } else {
        move <- sample(cur.clusters, na.size, rep = TRUE)
        time <- runif(na.size, min = 1, max = num.observs) + start.time 
        data <- merge(data, data.frame(clind = move, time = time), 
                      all = TRUE)
      }
    }
    start.time <- (max(data$time)%/%24 + 1)*24
  }
  if(num.outlier > 0){
    move <- rep(0, num.outlier)
    time <- runif(num.outlier, min = 1, 
                  max = num.observs*length(behaviours))	
    data <- merge(data, data.frame(clind = move, time = time), 
                  all = TRUE)
  }
  table.clust <- table(data$clind)
  if("0" %in% names(table.clust)) {
    clust.sizes <- table.clust[-1]
  } else clust.sizes <- table.clust
  num.clust <- length(clust.sizes)
  cldata <- genRandomClust(numClust = num.clust, sepVal = sep.val, 
                           clustszind = 3, clustSizes = clust.sizes, 
                           numOutlier = num.outlier, numNonNoisy = 2, 
                           numNoisy = 0, numReplicate = 1, 
                           fileName="clst", outputDatFlag = FALSE, 
                           outputLogFlag = FALSE, outputInfo = FALSE)
  clout <- data.frame(cldata$datList$clst_1, 
                      clind = cldata$memList$clst_1)
  clout <- clout[order(clout$clind),]
  rownames(clout) <- NULL
  rownames(data) <- NULL
  clout$time <- data$time
  if (num.outlier > 0){
    outlind <- which(clout$clind == 0)
    clout$clind[outlind] <- sample(num.clust, length(outlind), 
                                   replace = TRUE)
  }
  clout$time <- as.POSIXct(clout$time*3600, origin = "2012-01-01")
  names(clout) <- c("latitude", "longitude", "clind", 
                    "AuthenticationDate")
  clout <- clout[order(clout$AuthenticationDate), ]
  clout$clind <- as.factor(clout$clind)
  rownames(clout) <- NULL
  clout$AuthenticationDate <- strptime(clout$AuthenticationDate, 
                                       format = "%Y-%m-%d %H:%M:%S", 
                                       tz = "GMT")
  clout
}