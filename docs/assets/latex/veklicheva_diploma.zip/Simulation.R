source("Global_Source.r")
source("Data_Simulation.r")

# �������� �������������
max.periodogram <- function(data, periodogram.fun = spec.pgram, 
                            plot = FALSE, fast = FALSE, ...){
  spc <- periodogram.fun(scale(data), plot = plot, detrend = FALSE,
                         demean = TRUE, fast = fast, ...)
  max(spc$spec) - log(length(spc$spec))
}

# ���������� �������� ����� ��������������� ����
permutation.test <- function(data, periodogram.fun = spec.pgram, 
                             plot = FALSE, nrep = 100, 
                             alpha = .01, fast = FALSE, ...){
  dots <- list(...)
  spc.tmp <- replicate(nrep,
                       max(do.call(periodogram.fun,
                                   args = c(list(x = sample(data),
                                                 plot = plot,
                                                 fast = fast),
                                            unlist(dots)))$spec))
  
  spc.data <- periodogram.fun(data, plot = plot,fast = fast,...)
  res <- max(spc.data$spec) >= quantile(spc.tmp, 
                                        probs = (1-alpha), names = FALSE)
  res
}

# �������� ������ (���� �������) �� �������������:
# 0 - ��� �������������
# 1 - ���� �������������
periodicity.test <- function(data, periodogram.fun = spec.pgram, 
                             plot = FALSE, nrep = 100, alpha = .01, 
                             fast = FALSE,...){
  require("evd")	
  require("GeneCycle")
  f <- (fisher.g.test(scale(data)) < alpha)
  g <- (pgumbel(max.periodogram(data, periodogram.fun, fast = fast,...), 
                lower.tail = FALSE) < alpha)	
  pt <- permutation.test(data, periodogram.fun, alpha = alpha, 
                         nrep = nrep, fast = fast, ...)
  res <- as.numeric(c(f, g, pt))
  names(res) <- c("fisher","max.periodogram", "permutation")
  return (res)
}

# �������� ������ �� ������������� �� ���� ���������
test <- function(data, periodogram.fun = spec.pgram, alpha = .01, 
                 numClust = 7, power = 168, 
                 true.periods = NULL, 
                 nrep = 100, fast = FALSE, ... ){
  cluster <- 1:numClust
  expdata <- expand.data(data)
  expdata[is.na(expdata)] <- FALSE
  res <- sapply(cluster, function(cl){
    idx <- expdata == cl
    r <- range(which(idx))
    new.idx <- seq(from = r[1], to = r[2], by = 1)
    n <- (length(new.idx )%/% power) * power
    cldata <- as.numeric(idx[new.idx[1:n]])
    periodicity.test(cldata, periodogram.fun = periodogram.fun, 
                     alpha = alpha, fast = fast, nrep = nrep,...)
  })
  res <- t(res)
  if(!is.null(true.periods)) res <- cbind(res, true.periods)
  cbind(cluster, res)
}

# ����������� �� ��������� ���������� ������� ������������� � ���������
# 0 - ��� �������������
# 1 - ���� �������������
periodicity.in.clusters <- function(behaviours){
  per <- numeric()
  non.per <- numeric()
  for(x in behaviours){
    idx <- names(x) == "NA"
    per <- c(per, unlist(x[!idx]))
    non.per <- c(non.per, unlist(x[idx]))	
  }
  res <- numeric(length(unique(per)) + length(unique(non.per)))
  res[per] <- 1
  res
}

# ���������� ������� p �� ������� q
extension.matrix <- function(p,q){
  rp <- rownames(p)
  rq <- rownames(q)	
  idx <- which(!(rq %in% rp))
  if(length(idx) != 0){
    add.mtrx <- matrix(0, nrow = length(idx), ncol = ncol(p),
                       dimnames = list(rownames(q)[idx]))
    p1 <- rbind(p, add.mtrx)	
    p1 <- p1[order(rownames(p1)),]
  } else {
    p1 <- p
  }
  p1	
}

# ��������� �������������� ������
compare.matrix <- function(x,y, method = c("max","mean","JSD","con")){
  method <- match.arg(method)
  x1 <- extension.matrix(x,y)
  y1 <- extension.matrix(y,x)
  if (identical(method, "max")) res <- max(abs(x1-y1))
  if (identical(method, "mean"))res <- mean(abs(x1-y1))
  if (identical(method, "con")) res <- mean(abs(x1[-1,] - y1[-1,]))
  if (identical(method, "JSD")) res <- prob.JSD(x1,y1)
  res
}		

# ������������� �������������, ��������� - ������ ������. 
kmeans.clustering <- function(list.matrix, centers = 2, 
                              iter.max = 100, nstart = 1000, n_beh, 
                              km.method,...){
  if(!missing(n_beh)) centers = n_beh
  km <- matrix.kmeans(list.matrix, centers = centers, 
                      iter.max = iter.max, nstart = nstart, 
                      km.method = km.method)
  if (identical(km.method, "kmeans")){
    cluster <- km$cluster
  } 
  if (identical(km.method, "cclust")){
    cluster <- km@cluster	
  }
  list.matrix.after.clustering(list.matrix, cluster)
}

hclust.clustering <- function(list.matrix, period, move.seq, dist.func,
                              n_beh, ...){
  mc <- merge.and.error(list.matrix = list.matrix, T = period, 
                        S = move.seq, dist.func = dist.func)
  idx <- length(mc) - n_beh + 1
  mc[[idx]]$lmx
}

kmeans.hclust.clustering <- function(list.matrix, centers, iter.max = 100, 
                                     nstart = 1000, 
                                     period, move.seq, dist.func, n_beh, 
                                     km.method, ...){
  km <- kmeans.clustering(list.matrix, centers = centers, 
                          iter.max = iter.max, nstart = nstart, 
                          km.method = km.method)
  hclust.clustering(list.matrix = km, period = period, 
                    move.seq = move.seq, 
                    dist.func = dist.func, n_beh = n_beh)
}

prob.clustering <- function(list.matrix, method,...){
  method(list.matrix, ...)	
}

rest.algorithm <- function(sep.val, num.outlier, junk.rate, 
                           login.dev, observ.period, na.size, behaviours, 
                           list.beh.matrix, periodogram.fun, alpha, nrep, 
                           fast, real.periods, true.periods, all.methods, 
                           all.dist, n_beh, centers, iter.max, nstart,
                           km.method = "cclust"){
  data <- gen.data(sep.val = sep.val, num.outlier = num.outlier, 
                   junk.rate = junk.rate, login.dev = login.dev, 
                   observ.period = observ.period, na.size = na.size, 
                   behaviours = behaviours, 
                   list.beh.matrix = list.beh.matrix) 	
  exp.data <- expand.data(data)
  allperiods <- lapply(all.periods.periodogram(exp.data), 
                       function(x) x$periods)
  test.periodicity <- test(data = data, alpha = alpha,
                           periodogram.fun = periodogram.fun, 
                           numClust = length(table(exp.data)),
                           true.periods = true.periods,
                           nrep = nrep, fast = fast)
  res <- lapply(real.periods, function(period){
    stopifnot(length(in.which.clusters(period, allperiods))!= 0)
    move.seq <- move.seq.for.period(period, allperiods, exp.data)
    list.matrix <- list.matrix.segments(move.seq, period)
    require(plyr)
    list.res.beh <- llply(all.methods, function(cur.method){
      llply(all.dist, function(cur.dist){
        prob.clustering(list.matrix, 
                        method = cur.method, period = period, 
                        move.seq = move.seq, dist.func = cur.dist, 
                        n_beh = n_beh, centers = centers, 
                        iter.max = iter.max, nstart = nstart, 
                        km.method = km.method)
      })
    })
    list.res.beh[[length(list.res.beh) + 1]] <- list()
    list.res.beh[[length(list.res.beh)]][[1]] <- 
      kmeans.clustering(list.matrix, centers = n_beh, 
                        iter.max = iter.max, nstart = nstart, 
                        km.method = km.method)
    names(list.res.beh)[length(list.res.beh)] <- "kmeans.clustering"		
    list.res.beh
  })
  names(res) <- real.periods
  list(list.beh = res, periodicity = test.periodicity)
}

simulation <- function(Nrep = 1, sep.val = 0.4, num.outlier = 10, 
                       junk.rate = 0.1, login.dev = 0.15, 
                       observ.period = 10, na.size = 50, 
                       behaviours = list(list("24" = 1:2,"NA" = 4:5),
                                         list("24" = 3,"NA" = 6:7)),
                       regularity = list("24" = 3, "168" = 10), 
                       range.known.obs = c(.95,1), 
                       periodogram.fun = spec.pgram,
                       alpha = .05, nrep = 100, fast = FALSE,
                       centers = 10, iter.max = 1000, nstart = 1000, 
                       km.method = "cclust"){
  all.dist <- c(freq.KL = freq.KL, freq.JSD = freq.JSD, 
                hellinger.dist = hellinger.dist, 
                freq.KAI.KL = freq.KAI.KL, freq.KAI.JSD = freq.KAI.JSD)
  n.dist <- length(all.dist)
  all.methods <- c(hclust.clustering = hclust.clustering, 
                   kmeans.hclust.clustering = kmeans.hclust.clustering)
  n_beh <- length(behaviours)
  true.periods <- periodicity.in.clusters(behaviours)
  real.periods <- unique(as.vector(sapply(behaviours, 
                                          function(x) names(x))))
  real.periods <- as.numeric(real.periods[real.periods != "NA"])
  list.beh.matrix <- gen.beh.matrix(behaviours = behaviours,
                                    regularity = regularity, 
                                    range.known.obs = range.known.obs)
  res <- replicate(Nrep, 
                   rest.algorithm(sep.val = sep.val, 
                                  num.outlier = num.outlier, 
                                  junk.rate = junk.rate, 
                                  login.dev = login.dev, 
                                  observ.period = observ.period, 
                                  na.size = na.size, 
                                  behaviours = behaviours, 
                                  list.beh.matrix = list.beh.matrix, 
                                  periodogram.fun = periodogram.fun, 
                                  alpha = alpha, nrep = nrep, fast = fast, 
                                  real.periods = real.periods, 
                                  true.periods = true.periods, 
                                  all.methods = all.methods, 
                                  all.dist = all.dist, n_beh = n_beh, 
                                  centers = centers, iter.max = iter.max, 
                                  nstart = nstart, km.method = km.method))
  list(list.beh.matrix = list.beh.matrix, sim = res)
}

# ��������� ������������� N ��� � ����������� �����������
nrep.simulation <- function(N = 1, Nrep = 1, sep.val = 0.4, 
                            num.outlier = 10, junk.rate = 0.2, 
                            login.dev = 0.15, observ.period = 10, 
                            na.size = 150, 
                            behaviours = list(list("24" = 1:2,"NA" = 4:5),
                                              list("24" = 3,"NA" = 6:7)),
                            regularity = list("24" = 3, "168" = 10), 
                            range.known.obs = c(.95,1),
                            periodogram.fun = spec.pgram,
                            alpha = .05, nrep = 100, fast = FALSE,
                            centers = 10, iter.max = 10000, nstart = 1000, 
                            km.method = "cclust"){
  res.sim <- replicate(N, 
                       simulation(Nrep = Nrep, sep.val = sep.val, 
                                  num.outlier = num.outlier, 
                                  junk.rate = junk.rate, 
                                  login.dev = login.dev, 
                                  observ.period = observ.period, 
                                  na.size = na.size, 
                                  behaviours = behaviours, 
                                  regularity = regularity, 
                                  range.known.obs = range.known.obs,
                                  periodogram.fun = periodogram.fun, 
                                  alpha = alpha, nrep = nrep, 
                                  fast = fast,centers = centers,
                                  iter.max = iter.max, nstart = nstart, 
                                  km.method = km.method))		
  arg.list <- list(N = N, Nrep = Nrep, sep.val = sep.val, 
                   num.outlier = num.outlier, junk.rate = junk.rate, 
                   login.dev = login.dev, observ.period = observ.period, 
                   na.size = na.size, behaviours = behaviours, 
                   regularity = regularity, 
                   range.known.obs = range.known.obs, 
                   alpha = alpha, nrep = nrep, fast = fast, 
                   centers = centers, iter.max = iter.max, 
                   nstart = nstart, km.method = km.method)
  list(res.sim = res.sim, arg.list = arg.list)	
}

fixed.regularity <- function(N = 1, Nrep = 1, sep.val = 0.4, 
                             num.outlier = 10, observ.period = 10, 
                             na.size = 150, 
                             behaviours=list(list("24" = 1:2,"NA" = 4:5),
                                             list("24" = 3, "NA" = 6:7)),
                             regularity = list("24" = 3, "168" = 10), 
                             range.known.obs = c(.95,1), 
                             periodogram.fun = spec.pgram,
                             alpha = .05, nrep = 100, fast = FALSE,
                             centers = 10, iter.max = 1000, nstart = 1000, 
                             km.method = "cclust", 
                             file.name = "good_reg"){
  require("foreach")
  range.junk.rate <- seq(0, .5, by = .1)
  range.login.dev <- seq(0, 2, by = .25)	
  range.regularity <- lapply(seq(from = 2, to = 24, by = 2), 
                             function(x) list("24" = x, "168" = 10))	 
  foreach(cur.junk.rate = range.junk.rate) %:%
    foreach(cur.login.dev = range.login.dev) %:%
    foreach(cur.regularity = range.regularity) %do% {
      sim <- nrep.simulation(N = N, Nrep = Nrep, sep.val = sep.val, 
                             num.outlier = num.outlier, 
                             junk.rate = cur.junk.rate, 
                             login.dev = cur.login.dev, 
                             observ.period = observ.period, 
                             na.size = na.size, behaviours = behaviours,
                             regularity = cur.regularity, 
                             range.known.obs = range.known.obs, 
                             periodogram.fun = periodogram.fun,
                             alpha = alpha, nrep = nrep, fast = fast,
                             centers = centers, iter.max = iter.max, 
                             nstart = nstart, km.method = km.method)
      cur.names = paste(file.name, cur.junk.rate, 
                        cur.login.dev, cur.regularity[["24"]], sep = "_")
      save(sim, file = cur.names)
    }
  return(":)")
}